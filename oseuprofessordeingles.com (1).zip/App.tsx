
import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { HomeView } from './components/HomeView';
import { Marketplace } from './components/Marketplace';
import { StudentDashboard } from './components/StudentDashboard';
import { TeacherDashboard } from './components/TeacherDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { MacleyWidget } from './components/MacleyWidget';
import { AuthModal } from './components/AuthModal';
import { ToastContainer } from './components/Toast';
import { SquadHub } from './components/SquadHub';
import { TeacherProfileView } from './components/TeacherProfileView';
import { CourseDetailsView } from './components/CourseDetailsView';
import { BookingModal } from './components/BookingModal';
import { authService } from './services/authService';
import { squadService } from './services/squadService';
import { User, ViewState, UserRole, Teacher, Course, Booking, Notification, Squad } from './types';
import { MOCK_TEACHERS, MOCK_COURSES } from './constants';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentView, setCurrentView] = useState<ViewState>('HOME');
  const [selectedTeacherId, setSelectedTeacherId] = useState<string | null>(null);
  const [selectedCourseId, setSelectedCourseId] = useState<string | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [authInitialMode, setAuthInitialMode] = useState<'LOGIN' | 'REGISTER'>('LOGIN');
  const [notifications, setNotifications] = useState<Notification[]>([]);
  
  const [teachers] = useState<Teacher[]>(MOCK_TEACHERS);
  const [courses] = useState<Course[]>(MOCK_COURSES);
  const [activeSquads, setActiveSquads] = useState<Squad[]>(squadService.getSquads());
  const [bookings, setBookings] = useState<Booking[]>([]);

  useEffect(() => {
    authService.getCurrentUser().then(user => {
        if (user) setCurrentUser(user);
    });
  }, []);

  const handleLogout = async () => {
    await authService.signOut();
    setCurrentUser(null);
    setCurrentView('HOME');
  };

  const handleLogin = (u: User) => {
    setCurrentUser(u);
    setIsAuthModalOpen(false);
  };

  const handleOpenAuth = (mode: 'LOGIN' | 'REGISTER') => {
      setAuthInitialMode(mode);
      setIsAuthModalOpen(true);
  };

  const handleNavigateTeacher = (id: string) => {
      setSelectedTeacherId(id);
      setCurrentView('TEACHER_PROFILE');
      window.scrollTo(0,0);
  };

  const handleNavigateCourse = (id: string) => {
      setSelectedCourseId(id);
      setCurrentView('COURSE_DETAILS');
      window.scrollTo(0,0);
  };

  const handleConfirmBooking = (details: any) => {
      const newBooking: Booking = {
          id: `book_${Date.now()}`,
          teacherId: details.teacherId,
          teacherName: teachers.find(t => t.id === details.teacherId)?.name || 'Mestre',
          date: details.date.toLocaleDateString(),
          timeSlot: details.slot,
          paymentStatus: 'PAID'
      };
      setBookings(prev => [...prev, newBooking]);
      setIsBookingModalOpen(false);
      setNotifications(prev => [...prev, { id: Date.now().toString(), type: 'SUCCESS', message: 'Sincronia agendada com sucesso!' }]);
      setCurrentView('STUDENT_SYNC');
  };

  const handleShareSquad = (code: string) => {
      const link = `https://oseuprofessordeingles.com/join/${code}`;
      navigator.clipboard.writeText(link);
      setNotifications(prev => [...prev, { id: Date.now().toString(), type: 'SUCCESS', message: 'Link de convite neural copiado!' }]);
  };

  const selectedTeacher = teachers.find(t => t.id === selectedTeacherId);
  const selectedCourse = courses.find(c => c.id === selectedCourseId);

  return (
    <div className="bg-black text-gray-200 min-h-screen flex flex-col font-sans selection:bg-cyan-500 selection:text-black">
      <ToastContainer notifications={notifications} onDismiss={(id) => setNotifications(n => n.filter(x => x.id !== id))} />
      
      <Navbar 
        currentUser={currentUser} currentView={currentView} 
        onNavigate={(view) => { setCurrentView(view); setSelectedTeacherId(null); setSelectedCourseId(null); }} 
        onOpenAuth={handleOpenAuth} 
        onLogout={handleLogout} language="PT" onToggleLanguage={() => {}} 
      />

      <main className="flex-grow">
        {currentView === 'HOME' && (
            <HomeView 
                currentUser={currentUser} courses={courses} language="PT" favoriteIds={[]} 
                onNavigateTeacher={handleNavigateTeacher} 
                onNavigateCourse={handleNavigateCourse} 
                onNavigateAllCourses={() => setCurrentView('COURSES')} 
                onFindTeacher={() => setCurrentView('FIND_TEACHER')} 
                onStartSquad={() => currentUser ? setCurrentView('SQUAD_HUB') : handleOpenAuth('REGISTER')}
                onToggleFavorite={() => {}} 
            />
        )}

        {currentView === 'TEACHER_PROFILE' && selectedTeacher && (
            <TeacherProfileView 
                teacher={selectedTeacher} 
                similarTeachers={teachers.filter(t => t.id !== selectedTeacher.id)}
                onBook={() => currentUser ? setIsBookingModalOpen(true) : handleOpenAuth('LOGIN')}
                onNavigateTeacher={handleNavigateTeacher}
                onBack={() => setCurrentView('FIND_TEACHER')}
                language="PT"
            />
        )}

        {currentView === 'COURSE_DETAILS' && selectedCourse && (
            <CourseDetailsView 
                course={selectedCourse}
                isOwned={false}
                onBuy={() => currentUser ? handleNavigateCourse(selectedCourse.id) : handleOpenAuth('LOGIN')}
                onResume={() => setCurrentView('STUDENT_SYNC')}
                onNavigateInstructor={handleNavigateTeacher}
                language="PT"
            />
        )}

        {currentView === 'SQUAD_HUB' && currentUser && (
            <SquadHub 
                currentUser={currentUser} 
                activeSquads={activeSquads} 
                onNavigateTeacher={handleNavigateTeacher}
                onShare={handleShareSquad}
            />
        )}

        {currentView === 'STUDENT_SYNC' && currentUser && (
            <StudentDashboard currentUser={currentUser} bookings={bookings} activeSquads={activeSquads} />
        )}

        {currentView === 'TEACHER_REVENUE' && currentUser && <TeacherDashboard user={currentUser} />}
        {currentView === 'FIND_TEACHER' && <Marketplace currentUser={currentUser} type="teacher" items={teachers} favoriteIds={[]} language="PT" onNavigate={handleNavigateTeacher} onToggleFavorite={() => {}} />}
        {currentView === 'COURSES' && <Marketplace currentUser={currentUser} type="course" items={courses} favoriteIds={[]} language="PT" onNavigate={handleNavigateCourse} onToggleFavorite={() => {}} />}
      </main>

      <MacleyWidget currentUser={currentUser} language="PT" onAction={(action) => { if (action.type === 'NAVIGATE') setCurrentView(action.payload); }} />
      
      {isAuthModalOpen && <AuthModal initialMode={authInitialMode} onClose={() => setIsAuthModalOpen(false)} onLogin={handleLogin} />}
      
      {isBookingModalOpen && selectedTeacher && (
          <BookingModal 
            teacher={selectedTeacher} 
            onClose={() => setIsBookingModalOpen(false)} 
            onConfirm={handleConfirmBooking}
            language="PT"
          />
      )}

      <Footer onNavigate={setCurrentView as any} />
    </div>
  );
}
