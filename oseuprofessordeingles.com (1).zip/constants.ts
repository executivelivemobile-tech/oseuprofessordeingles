
import { Teacher, Course, BlogPost, Scenario, TeacherTier, PricingRule } from './types';

export const MACLEY_SYSTEM_INSTRUCTION = `
You are Macley, the Elite Concierge for "O Seu Professor de Inglês". 
Focus on user experience, teacher recommendations, and pedagogical support.
Be sleek, futuristic, and helpful. 
Use the 'navigate_to' tool to guide users through the platform.
`;

export const MOCK_TEACHERS: Teacher[] = [
  {
    id: 't1',
    name: 'Sarah Connor',
    photoUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=400&auto=format&fit=crop',
    niche: ['Business', 'Tech', 'Interviews'],
    location: 'San Francisco, USA',
    accent: 'USA',
    rating: 4.9,
    reviewCount: 128,
    hourlyRate: 150,
    bio: 'Specialist in English for Tech Professionals and Silicon Valley leadership communication.',
    verified: true,
    availability: { 'Mon': [9, 10, 14, 15], 'Tue': [9, 10, 14, 15] },
    reviews: [{ studentName: 'John Doe', rating: 5, comment: 'Excellent teacher for techies!', date: '2023-10-20' }],
    performanceMetrics: { hpc: 150, retention: 95 }
  },
  {
    id: 't2',
    name: 'James Bond',
    photoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=400&auto=format&fit=crop',
    niche: ['Diplomacy', 'Social', 'Accents'],
    location: 'London, UK',
    accent: 'UK',
    rating: 4.8,
    reviewCount: 95,
    hourlyRate: 180,
    bio: 'Master of British elegance, high-level social protocol, and persuasive communication.',
    verified: true,
    availability: { 'Wed': [10, 11, 13], 'Thu': [14, 15, 16] },
    performanceMetrics: { hpc: 180, retention: 98 }
  }
];

export const MOCK_COURSES: Course[] = [
  {
    id: 'c1',
    title: 'English for Full-Stack Developers',
    instructorId: 't1',
    instructorName: 'Sarah Connor',
    thumbnailUrl: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=400&auto=format&fit=crop',
    level: 'Intermediate',
    price: 497,
    category: 'Tech',
    duration: '12h',
    modules: 6,
    description: 'Master technical terminology and global collaboration.',
    syllabus: [{ title: 'Agile English', duration: '2h', lessons: ['Standups', 'Retrospectives'] }],
    features: ['Certificate', 'Mobile Access']
  }
];

export const MOCK_BLOG_POSTS: BlogPost[] = [
  {
    id: 'b1',
    title: 'How AI is Changing Learning',
    excerpt: 'Explore the neural future of language acquisition.',
    content: '<p>AI is augmenting, not replacing, the elite human teacher.</p>',
    imageUrl: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?q=80&w=800&auto=format&fit=crop',
    category: 'TIPS',
    author: 'Macley Editor',
    date: 'Oct 24, 2023',
    readTime: '5 min',
    status: 'PUBLISHED'
  }
];

export const MOCK_SCENARIOS: Scenario[] = [
  {
    id: 's1',
    title: 'Tech Interview',
    description: 'Practice with a Big Tech recruiter.',
    difficulty: 'Hard',
    category: 'Career',
    aiRole: 'Recruiter',
    userRole: 'Candidate',
    objective: 'Negotiate salary.',
    openingLine: 'Welcome. Tell me why you want to join our team.',
    imageUrl: 'https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?q=80&w=400&auto=format&fit=crop'
  }
];

// Added missing INITIAL_PRICING_RULE for ExecutiveAdvisor
export const INITIAL_PRICING_RULE: PricingRule = {
    baseTakeRate: 20,
    invisibleMarginBuffer: 5,
    tierDiscounts: {
        [TeacherTier.STARTER]: 0,
        [TeacherTier.VERIFIED]: 2,
        [TeacherTier.PRO]: 5,
        [TeacherTier.ELITE]: 8
    }
};

// Added missing INITIAL_METRIC_WEIGHTS for ExecutiveAdvisor
export const INITIAL_METRIC_WEIGHTS = {
    RETENTION: 40,
    HOURS: 30,
    REPURCHASE: 30
};
