
import { supabase } from './supabaseClient';
import { User, UserRole } from '../types';
import { getEnv } from '../utils/env';

const MASTER_CREDENTIALS = {
  email: 'admin@platform.com',
  pass: getEnv('ADMIN_PASSWORD') || 'master99'
};

const SESSION_STORAGE_KEY = 'ospi_synthetic_session';
const SANDBOX_USERS_KEY = 'ospi_sandbox_users';

export const authService = {
  getSyntheticSession(): User | null {
    const saved = localStorage.getItem(SESSION_STORAGE_KEY);
    return saved ? JSON.parse(saved) : null;
  },

  async signIn(email: string, password: string): Promise<User> {
    const cleanEmail = email.toLowerCase().trim();

    // 1. HARD-CODED ADMIN MASTER (Prioridade Máxima)
    if (cleanEmail === MASTER_CREDENTIALS.email && password === MASTER_CREDENTIALS.pass) {
      const adminUser: User = {
        id: 'root_master_01',
        email: cleanEmail,
        name: 'ADMIN MASTER',
        role: UserRole.SUPERADMIN,
        avatarUrl: 'https://ui-avatars.com/api/?name=Admin&background=ef4444&color=fff',
        isRoot: true,
        onboardingCompleted: true,
        isVerifiedTeacher: true,
        xp: 99999,
        rank: 'MASTER',
        neuralCapacity: { current: 1000, max: 1000, tier: 3, efficiencyBonus: 50 },
        meritStats: { 
            lessonsCompleted: 100, 
            materialsCreated: 50, 
            studentsMentored: 200, 
            avgRating: 5, 
            squadsLed: 10,
            passiveRevenue: 10000 
        }
      };
      localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(adminUser));
      return adminUser;
    }

    // 2. SUPABASE AUTH (Se disponível)
    if (supabase) {
        try {
            const { data, error } = await supabase.auth.signInWithPassword({ email: cleanEmail, password });
            if (!error && data.user) {
                return this.syncUserProfile(data.user);
            }
            // Se erro for especificamente "Invalid credentials", não cai no sandbox
            if (error && error.status === 400) throw error;
        } catch (e: any) {
            if (e.status === 400) throw e;
            console.warn("Supabase connection failed, falling back to Sandbox.");
        }
    }

    // 3. SANDBOX MODE (Fallback para Desenvolvimento/Demonstração)
    console.log("[AUTH] Entrando em Modo Sandbox.");
    const sandboxUser: User = {
        id: `sb_${Math.random().toString(36).substr(2, 9)}`,
        email: cleanEmail,
        name: cleanEmail.split('@')[0].toUpperCase(),
        role: cleanEmail.includes('teacher') ? UserRole.TEACHER : UserRole.STUDENT,
        avatarUrl: `https://ui-avatars.com/api/?name=${cleanEmail}&background=0D8ABC&color=fff`,
        onboardingCompleted: false,
        xp: 150,
        rank: 'NOVICE',
        neuralCapacity: { current: 100, max: 100, tier: 1, efficiencyBonus: 0 },
        meritStats: { lessonsCompleted: 0, materialsCreated: 0, studentsMentored: 0, avgRating: 0, squadsLed: 0, passiveRevenue: 0 }
    };

    localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(sandboxUser));
    return sandboxUser;
  },

  async signUp(email: string, pass: string, name: string, role: UserRole): Promise<User> {
    if (supabase) {
        const { data, error } = await supabase.auth.signUp({ 
            email, 
            password: pass,
            options: { data: { full_name: name, role } }
        });
        if (!error && data.user) return this.syncUserProfile(data.user);
    }
    
    // Sandbox SignUp
    return this.signIn(email, pass);
  },

  /**
   * FIX: Added missing updatePassword method to support SettingsView.tsx
   */
  async updatePassword(email: string, current: string, next: string): Promise<void> {
    if (supabase) {
        const { error } = await supabase.auth.updateUser({ password: next });
        if (error) throw error;
        return;
    }
    // Sandbox fallback: simulated delay
    await new Promise(r => setTimeout(r, 800));
  },

  async syncUserProfile(supabaseUser: any): Promise<User> {
    if (!supabase) throw new Error("Database link missing");

    /**
     * FIX: Changed from const to let because profile is reassigned on line 119
     */
    let { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', supabaseUser.id)
      .single();

    if (profileError || !profile) {
        // Cria perfil se não existir (First Login)
        const newProfile = {
            id: supabaseUser.id,
            full_name: supabaseUser.user_metadata?.full_name || 'Novo Humano',
            role: supabaseUser.user_metadata?.role || UserRole.STUDENT,
            avatar_url: `https://ui-avatars.com/api/?name=${supabaseUser.email}`,
            onboarding_completed: false,
            xp: 0,
            rank: 'NOVICE'
        };
        await supabase.from('profiles').insert([newProfile]);
        profile = newProfile;
    }

    const user: User = {
      id: profile.id,
      email: supabaseUser.email!,
      name: profile.full_name,
      role: profile.role as UserRole,
      avatarUrl: profile.avatar_url,
      onboardingCompleted: profile.onboarding_completed,
      xp: profile.xp || 0,
      rank: profile.rank || 'NOVICE',
      neuralCapacity: { current: 100, max: 100, tier: 1, efficiencyBonus: 0 },
      meritStats: { lessonsCompleted: 0, materialsCreated: 0, studentsMentored: 0, avgRating: 0, squadsLed: 0, passiveRevenue: 0 }
    };

    localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(user));
    return user;
  },

  async signOut() {
    localStorage.removeItem(SESSION_STORAGE_KEY);
    if (supabase) await supabase.auth.signOut();
  },

  async getCurrentUser(): Promise<User | null> {
    const synthetic = this.getSyntheticSession();
    if (synthetic) return synthetic;

    if (!supabase) return null;
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return null;

    return await this.syncUserProfile(session.user);
  }
};
