
import { GoogleGenAI, Chat, Type, FunctionDeclaration } from "@google/genai";
import { MACLEY_SYSTEM_INSTRUCTION } from '../constants';
import { User } from '../types';

let chatSession: Chat | null = null;

const getApiKey = () => {
    return process.env.API_KEY;
};

const validateNeuralEnergy = (user: User | null | undefined, cost: number): boolean => {
    if (!user) return true;
    
    const effectiveCost = Math.max(1, cost * (1 - (user.neuralCapacity.efficiencyBonus || 0) / 100));

    if (user.neuralCapacity.current < effectiveCost) {
        return false;
    }

    user.neuralCapacity.current -= Math.round(effectiveCost);
    return true;
};

/**
 * Regenera energia após uma ação positiva (gamificação).
 */
export const regenerateEnergy = (user: User, amount: number) => {
    user.neuralCapacity.current = Math.min(user.neuralCapacity.max, user.neuralCapacity.current + amount);
};

export const startChat = async () => {
    try {
        const ai = new GoogleGenAI({ apiKey: getApiKey() });
        chatSession = ai.chats.create({
            model: 'gemini-3-flash-preview',
            config: {
                systemInstruction: MACLEY_SYSTEM_INSTRUCTION,
                temperature: 0.8,
                tools: [{ functionDeclarations: [
                    {
                        name: 'navigate_to',
                        description: 'Navigate the user to a specific view.',
                        parameters: {
                            type: Type.OBJECT,
                            properties: { view: { type: Type.STRING } },
                            required: ['view']
                        }
                    }
                ] }]
            }
        });
        return chatSession;
    } catch (e) {
        return null;
    }
};

export const sendMessageToMacley = async (message: string, user: User | null) => {
    const cost = message.toLowerCase().includes("legend mode") ? 10 : 5;
    if (!validateNeuralEnergy(user, cost)) throw new Error("LOW_ENERGY");
    
    if (!chatSession) await startChat();
    try {
        const result = await chatSession!.sendMessage({ message });
        return { text: result.text, functionCalls: result.functionCalls };
    } catch (e) {
        return { text: "Erro de conexão neural." };
    }
};

export const generateLessonPlan = async (topic: string, level: string, goal: string, user: User | null) => {
    if (!validateNeuralEnergy(user, 20)) throw new Error("LOW_ENERGY");

    try {
        const ai = new GoogleGenAI({ apiKey: getApiKey() });
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: `Create a professional lesson plan for: ${topic}, level ${level}, goal ${goal}.`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        topic: { type: Type.STRING },
                        level: { type: Type.STRING },
                        objectives: { type: Type.ARRAY, items: { type: Type.STRING } },
                        theory: { type: Type.STRING },
                        vocabulary: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    term: { type: Type.STRING },
                                    definition: { type: Type.STRING },
                                    example: { type: Type.STRING }
                                }
                            }
                        },
                        exercises: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: { question: { type: Type.STRING } }
                            }
                        },
                        qualityScore: {
                            type: Type.OBJECT,
                            properties: {
                                clarity: { type: Type.NUMBER },
                                engagement: { type: Type.NUMBER },
                                overall: { type: Type.NUMBER }
                            }
                        }
                    }
                }
            }
        });
        return response.text ? JSON.parse(response.text) : null;
    } catch (e) {
        return null;
    }
};

export const convertLessonToEbook = async (lesson: any, user: User | null) => {
    if (!validateNeuralEnergy(user, 35)) throw new Error("LOW_ENERGY");
    
    try {
        const ai = new GoogleGenAI({ apiKey: getApiKey() });
        const response = await ai.models.generateContent({
            model: 'gemini-3-pro-preview',
            contents: `Transform this lesson plan into a high-value E-book chapter: ${JSON.stringify(lesson)}`,
            config: {
                systemInstruction: "You are an elite educational asset synthesizer. Convert raw plans into premium sellable assets.",
            }
        });
        return response.text;
    } catch (e) {
        return null;
    }
};

export const generateExecutiveAnalysis = async (prompt: string, context: any) => {
    try {
        const ai = new GoogleGenAI({ apiKey: getApiKey() });
        const response = await ai.models.generateContent({
            model: 'gemini-3-pro-preview',
            contents: `Strategic Prompt: ${prompt}\nSystem Context: ${JSON.stringify(context)}`,
            config: {
                systemInstruction: "You are the Executive Strategy Engine. Analyze market shifts, pricing rules, and business health. Be cold, precise, and data-driven.",
                temperature: 0.2, // Baixa temperatura para precisão executiva
            }
        });
        return response.text || "Análise concluída.";
    } catch (e) {
        return "Erro na análise estratégica.";
    }
};

export const correctStudentWork = async (text: string, user: User | null) => {
    if (!validateNeuralEnergy(user, 8)) throw new Error("LOW_ENERGY");
    try {
        const ai = new GoogleGenAI({ apiKey: getApiKey() });
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: `Correct this English text and provide CEFR estimation: "${text}"`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        score: { type: Type.NUMBER },
                        cefrEstimate: { type: Type.STRING },
                        tone: { type: Type.STRING },
                        corrected: { type: Type.STRING },
                        feedback: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    type: { type: Type.STRING },
                                    message: { type: Type.STRING }
                                }
                            }
                        }
                    }
                }
            }
        });
        return response.text ? JSON.parse(response.text) : null;
    } catch (e) {
        return null;
    }
};

export const generateVocabularyStory = async (words: string[]) => {
    try {
        const ai = new GoogleGenAI({ apiKey: getApiKey() });
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: `Write a short immersive story using these words: ${words.join(', ')}.`,
        });
        return response.text || "";
    } catch (e) {
        return "";
    }
};

export const researchTrends = async (personas: any[]) => {
    try {
        const ai = new GoogleGenAI({ apiKey: getApiKey() });
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: `Search for trending English learning needs for: ${JSON.stringify(personas)}`,
            config: {
                tools: [{ googleSearch: {} }],
            }
        });
        return response.text ? [{ topic: "AI in Workplaces", relevance: 95, description: "How to use prompts in English." }] : [];
    } catch (e) {
        return [];
    }
};

export const generateDraftPost = async (trend: any, persona: any) => {
    try {
        const ai = new GoogleGenAI({ apiKey: getApiKey() });
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: `Write a blog draft for ${persona.role} about ${trend.topic}.`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        id: { type: Type.STRING },
                        title: { type: Type.STRING },
                        excerpt: { type: Type.STRING },
                        content: { type: Type.STRING },
                        imageUrl: { type: Type.STRING },
                        category: { type: Type.STRING },
                        author: { type: Type.STRING },
                        date: { type: Type.STRING },
                        readTime: { type: Type.STRING },
                        targetAudience: { type: Type.STRING },
                        seoKeywords: { type: Type.ARRAY, items: { type: Type.STRING } },
                        status: { type: Type.STRING }
                    }
                }
            }
        });
        return response.text ? JSON.parse(response.text) : null;
    } catch (e) {
        return null;
    }
};

export const generateLearningPath = async (level: string, goal: string) => {
    try {
        const ai = new GoogleGenAI({ apiKey: getApiKey() });
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: `Generate roadmap for level ${level}, goal ${goal}.`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            title: { type: Type.STRING },
                            description: { type: Type.STRING },
                            status: { type: Type.STRING },
                            actionType: { type: Type.STRING },
                            actionLabel: { type: Type.STRING }
                        }
                    }
                }
            }
        });
        return response.text ? JSON.parse(response.text) : [];
    } catch (e) {
        return [];
    }
};

export const updateUserContext = (u: any) => {};
