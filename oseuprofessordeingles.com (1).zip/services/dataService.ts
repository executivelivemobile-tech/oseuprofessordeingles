
import { supabase } from './supabaseClient';
import { MOCK_TEACHERS, MOCK_COURSES, MOCK_BLOG_POSTS } from '../constants';
import { Teacher, Course, BlogPost, DigitalAsset } from '../types';

export const dataService = {
    async checkConnection() {
        if (!supabase) return false;
        try {
            const { error } = await supabase.from('profiles').select('count', { count: 'exact', head: true });
            return !error;
        } catch (e) {
            return false;
        }
    },

    async getTeachers(): Promise<Teacher[]> {
        if (!supabase) return MOCK_TEACHERS as any;
        
        const { data, error } = await supabase
            .from('teachers')
            .select('*')
            .eq('verified', true);
            
        if (error || !data) return MOCK_TEACHERS as any;
        return data as Teacher[];
    },

    async getCourses(): Promise<Course[]> {
        if (!supabase) return MOCK_COURSES;
        
        const { data, error } = await supabase
            .from('courses')
            .select('*');
            
        if (error || !data) return MOCK_COURSES;
        return data as Course[];
    },

    async getAdminMetrics() {
        if (!supabase) return {
            monthlyRevenue: 142800,
            takeRate: 28560,
            activeTeachers: MOCK_TEACHERS.length,
            assetRevenue: 5000,
            hpcAverage: 210
        };

        // Aqui viriam as agregações reais do banco (sum de transactions)
        return {
            monthlyRevenue: 142800,
            takeRate: 28560,
            activeTeachers: MOCK_TEACHERS.length,
            assetRevenue: 5000,
            hpcAverage: 210
        };
    },

    async getSecureExecutiveSnapshot() {
        const metrics = await this.getAdminMetrics();
        return {
            FINANCEIRO: {
                STATUS_RECEITA: 'EM_EXPANSAO',
                YIELD_ATIVOS: metrics.assetRevenue > 5000 ? 'ALTO' : 'CRESCENDO',
                HPC_GLOBAL: metrics.hpcAverage
            },
            META_DADOS: {
                LAST_SYNC: new Date().toISOString()
            }
        };
    },

    async getBlogPosts(): Promise<BlogPost[]> {
        if (!supabase) return MOCK_BLOG_POSTS;
        const { data } = await supabase.from('blog_posts').select('*').order('created_at', { ascending: false });
        return data || MOCK_BLOG_POSTS;
    },

    async publishGeneratedPost(post: BlogPost) {
        if (!supabase) return { success: true };
        const { error } = await supabase.from('blog_posts').insert([post]);
        return { success: !error };
    },

    async getAssetsByTeacher(teacherId: string): Promise<DigitalAsset[]> {
        if (!supabase) return [];
        const { data } = await supabase.from('digital_assets').select('*').eq('teacherId', teacherId);
        return data || [];
    },

    async publishAsset(asset: DigitalAsset) {
        if (!supabase) return { success: true };
        const { error } = await supabase.from('digital_assets').insert([asset]);
        return { success: !error };
    }
};
