
import { Squad, SquadMember, SquadStatus, User, Teacher } from '../types';

const STORAGE_KEY = 'ospi_active_squads';

export const squadService = {
    getSquads(): Squad[] {
        const saved = localStorage.getItem(STORAGE_KEY);
        return saved ? JSON.parse(saved) : [];
    },

    saveSquads(squads: Squad[]) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(squads));
    },

    createSquad(name: string, leader: User, teacher: Teacher): Squad {
        const squads = this.getSquads();
        const newSquad: Squad = {
            id: `sqd_${Math.random().toString(36).substr(2, 9)}`,
            name,
            leaderId: leader.id,
            teacherId: teacher.id,
            teacherName: teacher.name,
            targetNiche: teacher.niche[0],
            status: SquadStatus.RECRUITING,
            maxMembers: 4,
            minToActivate: 4,
            baseHourlyRate: teacher.hourlyRate,
            inviteCode: Math.random().toString(36).substr(2, 6).toUpperCase(),
            members: [{
                id: leader.id,
                name: leader.name,
                avatarUrl: leader.avatarUrl,
                isLeader: true,
                joinedAt: new Date().toISOString(),
                status: 'ACTIVE'
            }]
        };
        squads.push(newSquad);
        this.saveSquads(squads);
        return newSquad;
    },

    addMember(squadId: string, user: User): Squad | null {
        const squads = this.getSquads();
        const squadIndex = squads.findIndex(s => s.id === squadId);
        if (squadIndex === -1) return null;

        const squad = squads[squadIndex];
        if (squad.members.length >= squad.maxMembers) return squad;
        if (squad.members.some(m => m.id === user.id)) return squad;

        const newMember: SquadMember = {
            id: user.id,
            name: user.name,
            avatarUrl: user.avatarUrl,
            isLeader: false,
            joinedAt: new Date().toISOString(),
            status: 'ACTIVE'
        };

        squad.members.push(newMember);
        if (squad.members.length >= squad.minToActivate) {
            squad.status = SquadStatus.ACTIVE;
        }

        squads[squadIndex] = squad;
        this.saveSquads(squads);
        return squad;
    }
};
