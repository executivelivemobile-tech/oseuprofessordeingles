
import { Course, Teacher, User } from '../types';

export interface PaymentIntent {
    id: string;
    qrCode?: string;
    pixCopyPaste?: string;
    status: 'PENDING' | 'PAID' | 'FAILED';
    amount: number;
}

export const paymentService = {
    /**
     * Simula a chamada para a API do Pagar.me para criar um pedido com Split.
     */
    async createCoursePayment(course: Course, user: User): Promise<PaymentIntent> {
        console.log(`[PAYMENT] Iniciando transação para ${course.title}. Valor: R$ ${course.price}`);
        console.log(`[SPLIT] Vendedor: ${course.instructorName} (70%), Plataforma (30%)`);
        
        // Simulação de delay de rede da API
        await new Promise(r => setTimeout(r, 1500));

        return {
            id: `pay_${Math.random().toString(36).substr(2, 9)}`,
            qrCode: `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=00020126580014BR.GOV.BCB.PIX0136${course.id}5204000053039865802BR5925OSPI6009SaoPaulo62070503***6304`,
            pixCopyPaste: `00020126580014BR.GOV.BCB.PIX0136${course.id}5204000053039865802BR5925OSPI6009SaoPaulo62070503***6304`,
            status: 'PENDING',
            amount: course.price
        };
    },

    /**
     * Verifica o status via Webhook ou Polling
     */
    async checkPaymentStatus(paymentId: string): Promise<boolean> {
        // Simulação de confirmação pelo banco
        await new Promise(r => setTimeout(r, 2000));
        return true; 
    },

    async processCreditCard(cardData: any, amount: number): Promise<boolean> {
        console.log(`[PAYMENT] Processando Cartão de Crédito via Gateway Seguro...`);
        await new Promise(r => setTimeout(r, 3000));
        return true;
    }
};
