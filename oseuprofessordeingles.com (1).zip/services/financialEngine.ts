
import { TeacherWallet, LedgerEntry, TransactionType } from '../types';

/**
 * OSPI FINANCIAL CORE ENGINE
 * Regras Estritas de Soberania de Fluxo de Caixa.
 */
export const financialEngine = {
    
    async getTeacherWallet(teacherId: string): Promise<TeacherWallet> {
        const saved = localStorage.getItem(`wallet_${teacherId}`);
        if (saved) return JSON.parse(saved);
        
        return {
            currentBalance: 0,
            lastWithdrawalDate: null,
            totalEarnedLifetime: 0,
            entries: []
        };
    },

    /**
     * REGRA #1: O crédito ocorre exclusivamente APÓS o encerramento da aula.
     * ADIÇÃO: Verificação de duplicidade e existência de Chave PIX.
     */
    async creditLessonCompletion(teacherId: string, bookingId: string, hourlyRate: number): Promise<void> {
        const wallet = await this.getTeacherWallet(teacherId);
        
        // Proteção contra double-credit (duplicidade)
        const alreadyCredited = wallet.entries.some(e => e.referenceId === bookingId);
        if (alreadyCredited) {
            console.warn(`[SECURITY_ALERT] Tentativa de crédito duplicado detectada para booking ${bookingId}. Operação ignorada.`);
            return;
        }

        const platformFeePercent = 0.20; 
        const grossAmount = hourlyRate;
        const platformFee = grossAmount * platformFeePercent;
        const netAmount = grossAmount - platformFee;

        const newEntry: LedgerEntry = {
            id: `ledger_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
            teacherId,
            timestamp: new Date().toISOString(),
            type: 'LESSON_CREDIT',
            grossAmount,
            platformFee,
            netAmount,
            balanceAfter: wallet.currentBalance + netAmount,
            description: `Crédito por aula concluída (ID: ${bookingId})`,
            referenceId: bookingId
        };

        wallet.currentBalance += netAmount;
        wallet.totalEarnedLifetime += netAmount;
        wallet.entries.unshift(newEntry);

        localStorage.setItem(`wallet_${teacherId}`, JSON.stringify(wallet));
        console.log(`[FINANCE] Crédito processado para ${teacherId}. Novo saldo: R$ ${wallet.currentBalance}`);
    },

    async requestTotalWithdrawal(teacherId: string): Promise<{ success: boolean; message: string }> {
        const wallet = await this.getTeacherWallet(teacherId);
        const today = new Date().toISOString().split('T')[0];

        if (wallet.currentBalance <= 0) {
            return { success: false, message: "ERRO_SALDO_INSUFICIENTE: Operação bloqueada." };
        }

        if (wallet.lastWithdrawalDate === today) {
            return { success: false, message: "ERRO_FREQUENCIA: Limite de 1 saque a cada 24h atingido." };
        }

        // Simulação de verificação de conta bancária/PIX
        if (!wallet.pixKey && !localStorage.getItem(`pix_${teacherId}`)) {
             return { success: false, message: "ERRO_CONFIG: Chave PIX não encontrada. Atualize seu perfil." };
        }

        const withdrawAmount = wallet.currentBalance;
        
        const withdrawalEntry: LedgerEntry = {
            id: `withdr_${Date.now()}`,
            teacherId,
            timestamp: new Date().toISOString(),
            type: 'WITHDRAWAL_TOTAL',
            grossAmount: 0,
            platformFee: 0,
            netAmount: -withdrawAmount,
            balanceAfter: 0,
            description: `Saque Total Efetuado via PIX para ${wallet.pixKey || 'Chave Cadastrada'}`,
            referenceId: `payout_${Date.now()}`
        };

        wallet.currentBalance = 0;
        wallet.lastWithdrawalDate = today;
        wallet.entries.unshift(withdrawalEntry);

        localStorage.setItem(`wallet_${teacherId}`, JSON.stringify(wallet));
        
        return { 
            success: true, 
            message: `SUCESSO: Resgate de R$ ${withdrawAmount.toFixed(2)} enviado para sua chave PIX.` 
        };
    }
};
