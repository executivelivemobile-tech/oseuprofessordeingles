
import { TeacherTier, PricingRule, TeacherPOV } from '../types';

export const pricingService = {
  /**
   * Calcula quanto o aluno deve pagar.
   * Agora suporta o desconto neural aplicado pelo professor.
   */
  calculateMarketPrice(targetPayout: number, pov: TeacherPOV, rule: PricingRule, neuralDiscount: number = 0): number {
    // A taxa base é reduzida pelo tier do professor e pelo desconto neural ativo
    const tierDiscount = rule.tierDiscounts[pov.tier] || 0;
    const effectiveTakeRate = (rule.baseTakeRate - tierDiscount - neuralDiscount) / 100;
    
    // Preço Base para cobrir o que o professor quer receber
    const basePrice = targetPayout / (1 - Math.max(0.05, effectiveTakeRate));
    
    // Adição da Margem Invisível Estratégica
    const marketPrice = basePrice * (1 + rule.invisibleMarginBuffer / 100);
    
    return Math.ceil(marketPrice);
  },

  /**
   * Resolve o Tier baseado em valor gerado, incentivando a produtividade.
   */
  resolveTier(metrics: Partial<TeacherPOV>): TeacherTier {
    const { hoursDelivered30d = 0, retentionRate = 0, repurchaseRate = 0 } = metrics;

    if (hoursDelivered30d >= 80 && retentionRate >= 90) return TeacherTier.ELITE;
    if (hoursDelivered30d >= 40 && repurchaseRate >= 70) return TeacherTier.PRO;
    if (hoursDelivered30d >= 10) return TeacherTier.VERIFIED;
    
    return TeacherTier.STARTER;
  }
};
