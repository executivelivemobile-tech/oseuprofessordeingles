
export enum UserRole {
  STUDENT = 'STUDENT',
  TEACHER = 'TEACHER',
  ADMIN = 'ADMIN',
  SUPERADMIN = 'SUPERADMIN'
}

export type ViewState = 
  | 'HOME' | 'FIND_TEACHER' | 'COURSES' | 'TEACHER_REVENUE' 
  | 'STUDENT_SYNC' | 'ADMIN_MASTER' | 'ASSET_MARKET'
  | 'SQUAD_HUB' | 'SIMULATOR' | 'SETTINGS'
  | 'ADMIN_DASHBOARD' | 'ONBOARDING' | 'MESSAGES'
  | 'STUDENT_DASHBOARD' | 'TEACHER_DASHBOARD' | 'ABOUT' | 'BLOG' | 'TERMS' | 'PRIVACY' | 'FAQ' | 'REFERRALS' | 'VERIFY_CERTIFICATE'
  | 'TEACHER_PROFILE' | 'COURSE_DETAILS'; // NOVAS VIEWS ADICIONADAS

export enum SquadStatus {
    DRAFT = 'DRAFT',
    RECRUITING = 'RECRUITING',
    ACTIVE = 'ACTIVE',
    COMPLETED = 'COMPLETED'
}

export interface SquadMember {
    id: string;
    name: string;
    avatarUrl: string;
    isLeader: boolean;
    joinedAt: string;
    status: 'PENDING_WELCOME' | 'ACTIVE' | 'INACTIVE';
}

export interface Squad {
    id: string;
    name: string;
    leaderId: string;
    teacherId: string;
    teacherName: string;
    targetNiche: string;
    members: SquadMember[];
    maxMembers: number;
    minToActivate: number;
    status: SquadStatus;
    baseHourlyRate: number;
    inviteCode: string;
    welcomeSessionUrl?: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatarUrl: string;
  xp: number;
  rank: string;
  onboardingCompleted: boolean;
  neuralCapacity: {
      current: number;
      max: number;
      tier: number;
      efficiencyBonus: number;
  };
  meritStats: {
      lessonsCompleted: number;
      materialsCreated: number;
      studentsMentored: number;
      avgRating: number;
      squadsLed: number;
      passiveRevenue: number;
  };
  isRoot?: boolean;
  isVerifiedTeacher?: boolean;
  goal?: string;
  level?: string;
  timezone?: string;
  notifications?: { email: boolean; sms: boolean; promotions: boolean };
}

export interface Teacher {
    id: string;
    name: string;
    photoUrl: string;
    bio: string;
    hourlyRate: number;
    rating: number;
    verified: boolean;
    niche: string[];
    performanceMetrics: {
        hpc: number;
        retention: number;
    };
    location?: string;
    accent?: string;
    availability?: { [key: string]: number[] };
    reviews?: { studentName: string; rating: number; comment: string; date: string }[];
    reviewCount?: number;
    introVideoUrl?: string;
    pixKey?: string;
}

export interface Booking {
    id: string;
    teacherId: string;
    teacherName: string;
    date: string;
    timeSlot: string;
    paymentStatus: 'PENDING' | 'PAID' | 'REFUNDED';
    meetingUrl?: string;
}

export interface Course {
    id: string;
    title: string;
    instructorId: string;
    instructorName: string;
    thumbnailUrl: string;
    level: string;
    price: number;
    category: string;
    duration: string;
    modules: number;
    description: string;
    syllabus: CourseModule[];
    features: string[];
}

export interface CourseModule {
    title: string;
    duration: string;
    lessons: string[];
}

export interface BlogPost {
    id: string;
    title: string;
    excerpt: string;
    content: string;
    imageUrl: string;
    category: string;
    author: string;
    date: string;
    readTime: string;
    status: 'DRAFT' | 'PUBLISHED';
}

export interface Scenario {
    id: string;
    title: string;
    description: string;
    difficulty: 'Easy' | 'Medium' | 'Hard';
    category: string;
    aiRole: string;
    userRole: string;
    objective: string;
    openingLine: string;
    imageUrl: string;
}

export interface AIAction {
    type: 'NAVIGATE';
    payload: ViewState;
}

export interface Notification {
    id: string;
    type: 'SUCCESS' | 'ERROR' | 'INFO';
    message: string;
    date?: string;
    read?: boolean;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export enum TeacherTier {
    STARTER = 'STARTER',
    VERIFIED = 'VERIFIED',
    PRO = 'PRO',
    ELITE = 'ELITE'
}

export interface PricingRule {
    baseTakeRate: number;
    invisibleMarginBuffer: number;
    tierDiscounts: { [key in TeacherTier]: number };
}

export interface TimeSlot {
    id: string;
    time: string;
    available: boolean;
}

export interface DigitalAsset {
    id: string;
    teacherId: string;
    title: string;
    type: 'EBOOK' | 'COURSE' | 'AUDIO';
    status: 'LIVE' | 'DRAFT';
    sales: number;
    revenue: number;
    icon: string;
}

export interface Message {
    id: string;
    senderId: string;
    text: string;
    timestamp: Date;
}

export interface Conversation {
    id: string;
    partnerName: string;
    partnerAvatar: string;
    lastMessage: string;
    lastMessageTime: Date;
    unreadCount: number;
    messages: Message[];
}

export interface LedgerEntry {
    id: string;
    teacherId: string;
    timestamp: string;
    type: string;
    grossAmount: number;
    platformFee: number;
    netAmount: number;
    balanceAfter: number;
    description: string;
    referenceId: string;
}

export interface TeacherWallet {
    currentBalance: number;
    lastWithdrawalDate: string | null;
    totalEarnedLifetime: number;
    entries: LedgerEntry[];
    pixKey?: string;
}

export interface AssessmentQuestion {
    id: string;
    question: string;
    options: string[];
    correctIndex: number;
    levelWeight: number;
}

export interface LessonPlan {
    topic: string;
    level: string;
    objectives: string[];
    theory: string;
    vocabulary: { term: string; definition: string; example: string }[];
    exercises: { question: string }[];
    qualityScore: {
        clarity: number;
        engagement: number;
        overall: number;
    };
}

export interface StudentPersona {
    role: string;
    interests: string[];
    struggles: string[];
    count: number;
}

export interface HomeworkCorrection {
    score: number;
    cefrEstimate: string;
    tone: string;
    corrected: string;
    feedback: {
        type: 'GRAMMAR' | 'VOCAB' | 'STYLE';
        message: string;
    }[];
}

export interface VocabularyCard {
    id: string;
    term: string;
    definition: string;
    example: string;
    origin: 'HOMEWORK' | 'SIMULATOR' | 'CLASS';
    masteryLevel: number; // 0-5
}

export interface ContentTrend {
    topic: string;
    relevance: number;
    description: string;
}

export interface DraftPost extends BlogPost {
    targetAudience: string;
    seoKeywords: string[];
}

export interface RoadmapNode {
    title: string;
    description: string;
    status: 'COMPLETED' | 'ACTIVE' | 'LOCKED';
    actionType: string;
    actionLabel: string;
}

export interface Dispute {
    id: string;
    bookingId: string;
    reporterName: string;
    respondentName: string;
    reason: string;
    description: string;
    status: 'OPEN' | 'RESOLVED';
    createdAt: string;
}

export interface TeacherPOV {
    tier: TeacherTier;
    hoursDelivered30d: number;
    retentionRate: number;
    repurchaseRate: number;
}

export type TransactionType = 'LESSON_CREDIT' | 'WITHDRAWAL_TOTAL';
