
# O Seu Professor de Inglês | The Future of Learning Ecosystem

Esta é uma plataforma de ultra-performance para o aprendizado de inglês, conectando estudantes a mentores de elite e cursos premium, impulsionada pelo motor neural **Macley AI**.

## 🚀 Arquitetura do Sistema

- **Frontend**: React 19 + Tailwind CSS (Cyberpunk/Futurist Design)
- **Engine de IA**: Google Gemini 3 (Flash & Pro) para análise pedagógica, roleplay e automação de conteúdo.
- **Backend/Auth**: Supabase (PostgreSQL) com suporte a modo Mock para desenvolvimento rápido.
- **Soberania Financeira**: Sistema de Split de Pagamentos (Waterfall Fee) com prioridade por Item > Professor > Global.

## 🔐 Níveis de Acesso (RBAC)

1. **SUPERADMIN (Master)**: Único nível com acesso ao `MASTER_COMMAND_CENTER`. Imutável via código.
2. **ADMIN**: Operação de suporte e moderação.
3. **TEACHER**: Gestão de agenda, criação de cursos e integração com Google Docs/Notebooks.
4. **STUDENT**: Acesso ao Marketplace, Dashboard de Missões e Simuladores de IA.

## 🧠 Macley AI: Protocolos Especiais

A inteligência central (Macley) responde a comandos de voz e texto.
- **Trigger "Eu sou a lenda"**: Ativa o Protocolo Legend, permitindo que a IA explique gírias e linguagens complexas com profundidade cultural.
- **Navigate Tool**: Macley pode teleportar o usuário entre seções da plataforma apenas via conversa.

## 🛠️ Configuração de Desenvolvimento

1. Instale as dependências:
   ```bash
   npm install
   ```

2. Configure sua chave mestra no arquivo `.env`:
   ```env
   API_KEY=sua_chave_gemini_aqui
   VITE_SUPABASE_URL=sua_url_supabase
   VITE_SUPABASE_KEY=sua_chave_anonima
   ```

3. Inicie o terminal:
   ```bash
   npm run dev
   ```

## 🛡️ Credenciais de Teste Master (Mock Mode)
- **User**: `admin@platform.com`
- **Pass**: `master99`

---
*Enginereed by Neural Link Architect.*
