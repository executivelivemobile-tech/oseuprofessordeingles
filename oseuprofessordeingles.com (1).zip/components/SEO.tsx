
import React, { useEffect } from 'react';

interface SEOProps {
    title?: string;
    description?: string;
    image?: string;
    url?: string;
}

export const SEO: React.FC<SEOProps> = ({ 
    title = "O Seu Professor de Inglês | The Future of Learning", 
    description = "Plataforma de ultra-performance para aprender inglês com mentores de elite e Macley AI.",
    image = "https://ui-avatars.com/api/?name=OSPI&background=0D8ABC&color=fff&size=512",
    url = "https://oseuprofessordeingles.com"
}) => {
    useEffect(() => {
        document.title = title;
        
        const updateMeta = (name: string, content: string, property = false) => {
            const attr = property ? 'property' : 'name';
            let el = document.querySelector(`meta[${attr}="${name}"]`);
            if (!el) {
                el = document.createElement('meta');
                el.setAttribute(attr, name);
                document.head.appendChild(el);
            }
            el.setAttribute('content', content);
        };

        updateMeta('description', description);
        updateMeta('og:title', title, true);
        updateMeta('og:description', description, true);
        updateMeta('og:image', image, true);
        updateMeta('og:url', url, true);
        updateMeta('twitter:card', 'summary_large_image');
    }, [title, description, image, url]);

    return null; // Componente puramente funcional de head
};
