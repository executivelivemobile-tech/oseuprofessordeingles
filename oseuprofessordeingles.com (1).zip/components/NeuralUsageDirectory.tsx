
import React from 'react';
import { UserRole } from '../types';

interface UtilityItem {
    id: string;
    name: string;
    cost: number;
    desc: string;
    icon: string;
    role: UserRole;
    gradient: string;
}

const UTILITIES: UtilityItem[] = [
    { id: 'sim', name: 'Simulação de Missão', cost: 15, desc: 'Roleplay imersivo com Macley em cenários de alta pressão.', icon: '🎯', role: UserRole.STUDENT, gradient: 'from-cyan-600 to-blue-600' },
    { id: 'legend', name: 'Legend Mode', cost: 10, desc: 'Tradução cultural profunda e gírias nativas avançadas.', icon: '👑', role: UserRole.STUDENT, gradient: 'from-purple-600 to-pink-600' },
    { id: 'essay', name: 'Neural Proofread', cost: 8, desc: 'Correção de redação com análise de tom e vocabulário C2.', icon: '✍️', role: UserRole.STUDENT, gradient: 'from-blue-600 to-indigo-600' },
    { id: 'plan', name: 'Lesson Architect', cost: 20, desc: 'Criação instantânea de plano de aula via Google Docs.', icon: '📐', role: UserRole.TEACHER, gradient: 'from-emerald-600 to-teal-600' },
    { id: 'asset', name: 'Asset Synthesis', cost: 35, desc: 'Converte aula gravada em E-book estruturado para venda.', icon: '💎', role: UserRole.TEACHER, gradient: 'from-orange-600 to-red-600' },
    { id: 'trends', name: 'Trend Hunter', cost: 15, desc: 'IA pesquisa tópicos quentes no Google para seu Blog.', icon: '🔥', role: UserRole.TEACHER, gradient: 'from-cyan-500 to-emerald-500' },
];

export const NeuralUsageDirectory: React.FC<{ userRole: UserRole }> = ({ userRole }) => {
    const filtered = UTILITIES.filter(u => u.role === userRole);

    return (
        <div className="space-y-6 animate-fade-in">
            <div className="flex items-center justify-between border-b border-gray-800 pb-4">
                <h3 className="text-white font-orbitron font-bold text-sm tracking-widest uppercase">Diretório de Utilidade Neural</h3>
                <span className="text-[10px] text-gray-500 font-mono">ENCRYPTED_SERVICES_V1</span>
            </div>
            
            <div className="grid gap-4">
                {filtered.map(item => (
                    <div key={item.id} className="group bg-gray-900/40 border border-gray-800 rounded-2xl p-4 hover:border-gray-600 transition-all cursor-pointer relative overflow-hidden">
                        {/* Hover Gradient Glow */}
                        <div className={`absolute -inset-1 bg-gradient-to-r ${item.gradient} opacity-0 group-hover:opacity-5 blur-xl transition-opacity`}></div>
                        
                        <div className="flex items-center gap-4 relative z-10">
                            <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${item.gradient} flex items-center justify-center text-2xl shadow-lg shadow-black/50`}>
                                {item.icon}
                            </div>
                            <div className="flex-1">
                                <div className="flex justify-between items-center mb-1">
                                    <h4 className="text-white font-bold text-sm">{item.name}</h4>
                                    <span className="text-cyan-400 font-mono text-xs font-bold">{item.cost} NS</span>
                                </div>
                                <p className="text-[11px] text-gray-400 leading-tight">{item.desc}</p>
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            <div className="bg-cyan-900/10 border border-cyan-500/20 rounded-xl p-4 text-center">
                <p className="text-[10px] text-cyan-400 font-bold uppercase tracking-widest mb-1">Status da Célula</p>
                <p className="text-[10px] text-gray-500 italic">Sua energia regenera +5 NS a cada aula completada com sucesso.</p>
            </div>
        </div>
    );
};
