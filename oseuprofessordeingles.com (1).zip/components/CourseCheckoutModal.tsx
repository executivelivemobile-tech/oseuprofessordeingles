
import React, { useState, useEffect } from 'react';
import { Course, User } from '../types';
import { paymentService, PaymentIntent } from '../services/paymentService';

interface CourseCheckoutModalProps {
  course: Course;
  user: User;
  onClose: () => void;
  onConfirm: () => void;
  language?: 'EN' | 'PT';
}

export const CourseCheckoutModal: React.FC<CourseCheckoutModalProps> = ({ course, user, onClose, onConfirm, language = 'EN' }) => {
  const [step, setStep] = useState<'PAYMENT' | 'PROCESSING' | 'SUCCESS'>('PAYMENT');
  const [method, setMethod] = useState<'CC' | 'PIX'>('CC');
  const [pixIntent, setPixIntent] = useState<PaymentIntent | null>(null);
  const [pixTimeLeft, setPixTimeLeft] = useState(600);
  const [isGenerating, setIsGenerating] = useState(false);
  const isPT = language === 'PT';

  useEffect(() => {
    if (method === 'PIX' && !pixIntent && !isGenerating) {
        generatePix();
    }
  }, [method]);

  const generatePix = async () => {
    setIsGenerating(true);
    const intent = await paymentService.createCoursePayment(course, user);
    setPixIntent(intent);
    setIsGenerating(false);
  };

  const handlePayCC = async (e: React.FormEvent) => {
    e.preventDefault();
    setStep('PROCESSING');
    const success = await paymentService.processCreditCard({}, course.price);
    if (success) setStep('SUCCESS');
    else {
        alert("Transação negada pela operadora.");
        setStep('PAYMENT');
    }
  };

  const handleCopyPix = () => {
      if (pixIntent?.pixCopyPaste) {
        navigator.clipboard.writeText(pixIntent.pixCopyPaste);
        alert("Código PIX copiado!");
      }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-fade-in font-sans">
      <div className="w-full max-w-4xl bg-[#0a0a0a] border border-white/10 rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col md:flex-row h-auto max-h-[90vh]">
        
        {/* Sumário (Identidade Visual O Seu Professor) */}
        <div className="w-full md:w-5/12 bg-black p-8 flex flex-col border-b md:border-b-0 md:border-r border-white/5">
            <h3 className="text-gray-500 text-[10px] uppercase font-black mb-8 tracking-[0.3em]">{isPT ? 'RESUMO_DA_MISSÃO' : 'MISSION_SUMMARY'}</h3>
            
            <div className="flex-1">
                <div className="relative aspect-video rounded-3xl overflow-hidden mb-6 shadow-2xl border border-white/5">
                    <img src={course.thumbnailUrl} alt={course.title} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"></div>
                </div>
                
                <h2 className="text-2xl font-bold text-white mb-2 leading-tight font-orbitron">{course.title}</h2>
                <p className="text-sm text-cyan-500 mb-6 font-mono">Instrutor: {course.instructorName}</p>
                
                <div className="space-y-4">
                    <div className="flex items-center gap-3 text-xs text-gray-400">
                        <div className="w-5 h-5 rounded-full bg-green-900/30 flex items-center justify-center text-green-500">✓</div>
                        Acesso Vitalício ao Terminal
                    </div>
                    <div className="flex items-center gap-3 text-xs text-gray-400">
                        <div className="w-5 h-5 rounded-full bg-green-900/30 flex items-center justify-center text-green-500">✓</div>
                        Certificado Neural OSPI
                    </div>
                </div>
            </div>

            <div className="mt-12 pt-8 border-t border-white/5">
                <div className="flex justify-between items-center mb-6">
                    <span className="text-white font-bold uppercase tracking-widest text-xs">Total</span>
                    <span className="text-4xl font-black text-white font-mono">R$ {course.price}</span>
                </div>
                <div className="flex items-center justify-center gap-2 text-[10px] text-gray-600 bg-white/5 py-3 rounded-2xl uppercase font-black tracking-widest">
                    <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>
                    Gateway Seguro: AES-256 Bit
                </div>
            </div>
        </div>

        {/* Formulário de Pagamento Transparente */}
        <div className="w-full md:w-7/12 p-8 md:p-12 flex flex-col relative bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]">
            <button onClick={onClose} className="absolute top-6 right-6 text-gray-600 hover:text-white transition-colors">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
            </button>

            {step === 'PAYMENT' && (
                <div className="animate-slide-up h-full flex flex-col">
                    <h3 className="text-xl font-bold text-white mb-8 font-orbitron tracking-tight">MÉTODO_DE_PAGAMENTO</h3>
                    
                    <div className="flex bg-black/40 p-1.5 rounded-2xl mb-8 border border-white/5">
                        <button 
                            onClick={() => setMethod('CC')}
                            className={`flex-1 py-4 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${method === 'CC' ? 'bg-white text-black shadow-xl' : 'text-gray-500 hover:text-white'}`}
                        >
                            Cartão de Crédito
                        </button>
                        <button 
                            onClick={() => setMethod('PIX')}
                            className={`flex-1 py-4 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${method === 'PIX' ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-900/40' : 'text-gray-500 hover:text-white'}`}
                        >
                            PIX Instantâneo
                        </button>
                    </div>

                    {method === 'CC' && (
                        <form onSubmit={handlePayCC} className="space-y-6 flex-1">
                            <div className="space-y-1">
                                <label className="block text-[10px] text-gray-500 uppercase font-black ml-2 tracking-widest">Número do Cartão</label>
                                <input required className="w-full bg-black border border-white/10 rounded-2xl px-5 py-4 text-white focus:border-white focus:outline-none font-mono" placeholder="0000 0000 0000 0000" />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-1">
                                    <label className="block text-[10px] text-gray-500 uppercase font-black ml-2 tracking-widest">Validade</label>
                                    <input required className="w-full bg-black border border-white/10 rounded-2xl px-5 py-4 text-white focus:border-white focus:outline-none text-center font-mono" placeholder="MM/YY" />
                                </div>
                                <div className="space-y-1">
                                    <label className="block text-[10px] text-gray-500 uppercase font-black ml-2 tracking-widest">CVC</label>
                                    <input required className="w-full bg-black border border-white/10 rounded-2xl px-5 py-4 text-white focus:border-white focus:outline-none text-center font-mono" placeholder="123" />
                                </div>
                            </div>
                            <div className="space-y-1">
                                <label className="block text-[10px] text-gray-500 uppercase font-black ml-2 tracking-widest">Nome Impresso</label>
                                <input required className="w-full bg-black border border-white/10 rounded-2xl px-5 py-4 text-white focus:border-white focus:outline-none uppercase" placeholder="COMO ESTÁ NO CARTÃO" />
                            </div>
                            
                            <div className="pt-6">
                                <button type="submit" className="w-full py-5 rounded-3xl bg-white text-black font-black text-xs uppercase tracking-[0.3em] hover:bg-cyan-400 transition-all shadow-xl active:scale-95">
                                    Confirmar Matrícula
                                </button>
                            </div>
                        </form>
                    )}

                    {method === 'PIX' && (
                        <div className="space-y-8 flex-1 flex flex-col items-center justify-center animate-fade-in">
                             {isGenerating ? (
                                 <div className="w-48 h-48 rounded-3xl bg-white/5 border border-white/10 flex items-center justify-center">
                                     <div className="w-8 h-8 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin"></div>
                                 </div>
                             ) : (
                                <div className="bg-white p-4 rounded-[2.5rem] shadow-2xl scale-110 group relative">
                                    <div className="absolute inset-0 bg-cyan-500 blur-2xl opacity-10 group-hover:opacity-20 transition-opacity"></div>
                                    <img src={pixIntent?.qrCode} alt="PIX QR" className="w-44 h-44 relative z-10" />
                                </div>
                             )}
                             
                             <div className="text-center">
                                <p className="text-white font-bold text-lg mb-1">Aguardando Pagamento...</p>
                                <p className="text-cyan-500 text-[10px] font-black uppercase tracking-widest animate-pulse">Sincronizando com o Banco Central</p>
                             </div>

                             <button 
                                onClick={handleCopyPix}
                                className="w-full bg-black/60 border border-white/10 text-gray-400 hover:text-white py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-3"
                             >
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" /></svg>
                                Copiar Código PIX Copia-e-Cola
                             </button>

                             <p className="text-gray-600 text-[9px] uppercase font-black tracking-tighter">O acesso será liberado instantaneamente após a confirmação.</p>
                        </div>
                    )}
                </div>
            )}

            {step === 'PROCESSING' && (
                 <div className="h-full flex flex-col items-center justify-center animate-pulse">
                     <div className="w-24 h-24 border-4 border-cyan-500 border-t-transparent rounded-full animate-spin mb-8 shadow-[0_0_30px_rgba(6,182,212,0.3)]"></div>
                     <h3 className="text-2xl font-bold text-white mb-2 font-orbitron">VALIDANDO_PROTOCOLOS</h3>
                     <p className="text-gray-500 text-xs font-mono uppercase tracking-widest">Comunicando com gateway de pagamento...</p>
                 </div>
            )}

            {step === 'SUCCESS' && (
                 <div className="h-full flex flex-col items-center justify-center text-center animate-scale-in">
                     <div className="w-24 h-24 bg-green-500 rounded-full flex items-center justify-center mb-8 shadow-[0_0_40px_rgba(34,197,94,0.4)]">
                         <svg className="w-12 h-12 text-black" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={4} d="M5 13l4 4L19 7" /></svg>
                     </div>
                     <h3 className="text-3xl font-black text-white mb-2 font-orbitron tracking-tight uppercase">ACESSO_LIBERADO</h3>
                     <p className="text-gray-500 text-sm mb-12 max-w-sm">
                         Sua sincronização foi concluída com sucesso. O curso já está disponível no seu console de missões.
                     </p>
                     <button 
                         onClick={onConfirm}
                         className="w-full py-5 rounded-3xl bg-cyan-600 text-white font-black text-xs uppercase tracking-[0.3em] shadow-2xl shadow-cyan-900/40 hover:bg-cyan-500 transition-all"
                     >
                         Acessar Material Agora
                     </button>
                 </div>
            )}

        </div>
      </div>
    </div>
  );
};
