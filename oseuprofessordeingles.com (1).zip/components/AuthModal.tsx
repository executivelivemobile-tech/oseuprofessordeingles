
import React, { useState } from 'react';
import { User, UserRole } from '../types';
import { authService } from '../services/authService';
import { supabase } from '../services/supabaseClient';

interface AuthModalProps {
  initialMode?: 'LOGIN' | 'REGISTER' | 'ADMIN';
  onClose: () => void;
  onLogin: (user: User) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ initialMode = 'LOGIN', onClose, onLogin }) => {
  const [mode, setMode] = useState<'LOGIN' | 'REGISTER' | 'ADMIN'>(initialMode);
  const [selectedRole, setSelectedRole] = useState<UserRole>(UserRole.STUDENT);
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loginStep, setLoginStep] = useState<string>('');
  
  const [formData, setFormData] = useState({ name: '', email: '', password: '' });

  const themeColor = mode === 'ADMIN' ? 'red' : (selectedRole === UserRole.TEACHER && mode === 'REGISTER' ? 'purple' : 'cyan');
  const isSupabaseOnline = !!supabase;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    
    const steps = ["LINKING_CORE...", "DECRYPTING...", "AUTHORIZING..."];
    for(const step of steps) {
        setLoginStep(step);
        await new Promise(r => setTimeout(r, 400));
    }

    try {
        let user;
        if (mode === 'REGISTER') {
            user = await authService.signUp(formData.email, formData.password, formData.name, selectedRole);
        } else {
            user = await authService.signIn(formData.email, formData.password);
        }
        onLogin(user);
        onClose();
    } catch (err: any) {
        setError(err.message || "Falha na sincronização.");
        setIsLoading(false);
    }
  };

  const getTitle = () => {
      if (isLoading) return loginStep;
      if (mode === 'ADMIN') return 'ROOT_ACCESS';
      if (mode === 'LOGIN') return 'RE_CONNECT';
      return 'INITIALIZE_PROTOCOL';
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl animate-fade-in font-sans">
      <div className={`w-full max-w-md bg-gray-950 border-2 rounded-[2.5rem] overflow-hidden relative shadow-2xl transition-all duration-500 ${
          themeColor === 'red' ? 'border-red-600 shadow-red-900/20' : 
          themeColor === 'purple' ? 'border-purple-600 shadow-purple-900/20' : 
          'border-cyan-600 shadow-cyan-900/20'
      }`}>
        
        {isLoading && <div className="absolute left-0 w-full h-1 bg-white z-50 animate-scan"></div>}

        <div className="p-10 relative z-10">
          <header className="text-center mb-8">
            <div className={`w-16 h-16 mx-auto mb-6 rounded-2xl flex items-center justify-center shadow-lg ${
                mode === 'ADMIN' ? 'bg-red-600' : (themeColor === 'purple' ? 'bg-purple-600' : 'bg-cyan-600')
            }`}>
                <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
            </div>
            <h2 className="text-2xl font-orbitron font-black text-white tracking-tighter uppercase leading-none">
                {getTitle()}
            </h2>
            
            <div className="mt-4 flex items-center justify-center gap-2">
                <div className={`w-1.5 h-1.5 rounded-full ${isSupabaseOnline ? 'bg-green-500' : 'bg-yellow-500 animate-pulse'}`}></div>
                <span className="text-[9px] font-mono text-gray-500 uppercase tracking-[0.4em]">
                    {isSupabaseOnline ? 'Secure Cloud Sync' : 'Offline Sandbox Mode'}
                </span>
            </div>
          </header>

          {mode === 'REGISTER' && (
              <div className="flex gap-2 mb-8 bg-black/40 p-1.5 rounded-2xl border border-white/5">
                  <button onClick={() => setSelectedRole(UserRole.STUDENT)} className={`flex-1 py-3 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all ${selectedRole === UserRole.STUDENT ? 'bg-cyan-600 text-white shadow-lg' : 'text-gray-600 hover:text-gray-400'}`}>Estudante</button>
                  <button onClick={() => setSelectedRole(UserRole.TEACHER)} className={`flex-1 py-3 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all ${selectedRole === UserRole.TEACHER ? 'bg-purple-600 text-white shadow-lg' : 'text-gray-600 hover:text-gray-400'}`}>Mentor</button>
              </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            {mode === 'REGISTER' && (
                <div>
                    <label className="block text-[10px] text-gray-500 font-black uppercase mb-1.5 ml-2 tracking-widest">Identidade Nomimal</label>
                    <input name="name" type="text" required value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} className="w-full bg-black border border-white/10 rounded-2xl px-5 py-4 text-white focus:border-white outline-none text-sm" placeholder="Nome Completo" />
                </div>
            )}

            <div>
                <label className="block text-[10px] text-gray-500 font-black uppercase mb-1.5 ml-2 tracking-widest">Canal de E-mail</label>
                <input name="email" type="email" required value={formData.email} onChange={(e) => setFormData({...formData, email: e.target.value})} className="w-full bg-black border border-white/10 rounded-2xl px-5 py-4 text-white focus:border-white outline-none font-mono text-sm" placeholder="user@neural.link" />
            </div>

            <div className="relative">
                <label className="block text-[10px] text-gray-500 font-black uppercase mb-1.5 ml-2 tracking-widest">Chave de Acesso</label>
                <input name="password" type={showPassword ? "text" : "password"} required value={formData.password} onChange={(e) => setFormData({...formData, password: e.target.value})} className="w-full bg-black border border-white/10 rounded-2xl px-5 py-4 text-white focus:border-white outline-none font-mono text-sm" placeholder="••••••••" />
                <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 bottom-4 text-gray-600 hover:text-white">
                    {showPassword ? '🙈' : '👁️'}
                </button>
            </div>

            {error && <p className="text-red-500 text-[10px] font-bold text-center uppercase py-2 bg-red-950/20 rounded-lg border border-red-900/50">{error}</p>}

            <button type="submit" disabled={isLoading} className={`w-full py-5 rounded-3xl font-black text-white text-xs uppercase tracking-[0.3em] transition-all flex items-center justify-center gap-3 active:scale-95 disabled:opacity-50 ${
                themeColor === 'red' ? 'bg-red-600' : (themeColor === 'purple' ? 'bg-purple-600' : 'bg-cyan-600')
            }`}>
                {mode === 'REGISTER' ? 'INITIALIZE_LINK' : 'ESTABLISH_LINK'}
            </button>
          </form>

          <div className="mt-8 pt-6 border-t border-white/5 flex flex-col items-center gap-4">
            <button onClick={() => setMode(mode === 'LOGIN' ? 'REGISTER' : 'LOGIN')} className="text-[10px] font-black text-gray-400 hover:text-white uppercase tracking-widest transition-colors">
                {mode === 'LOGIN' ? 'Criar Nova Identidade Neural' : 'Já possuo um link de acesso'}
            </button>
            <button onClick={onClose} className="text-[10px] font-black text-gray-700 hover:text-red-500 uppercase tracking-widest transition-colors">Abortar_Protocolo</button>
          </div>
        </div>
      </div>
    </div>
  );
};
