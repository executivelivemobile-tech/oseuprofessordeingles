
import React, { useMemo, useState } from 'react';
import { Teacher } from '../types';
import { TeacherCard, VerifiedBadge } from './Cards';

interface TeacherProfileViewProps {
  teacher: Teacher;
  similarTeachers: Teacher[];
  onBook: (duration: number) => void;
  onNavigateTeacher: (id: string) => void;
  onBack: () => void;
  language: 'EN' | 'PT';
}

const ElitePackageCard: React.FC<{ teacher: Teacher; onBook: (d: number) => void; language: 'EN' | 'PT' }> = ({ teacher, onBook, language }) => {
    const [duration, setDuration] = useState<1 | 3 | 6 | 12>(6);

    const packageStats = useMemo(() => {
        let totalSlots, discountPercent, label, subLabel, bonuses, margin;
        const isPT = language === 'PT';

        switch (duration) {
            case 1: 
                totalSlots = 1;
                discountPercent = 0;
                margin = 0;
                label = isPT ? "Sessão Experimental" : "Trial Session";
                subLabel = isPT ? "Teste a conexão" : "Test the connection";
                bonuses = [
                    isPT ? "50 Minutos de Aula 1:1" : "50 Minutes 1:1 Lesson",
                    isPT ? "Relatório de Feedback IA" : "AI Feedback Report",
                    isPT ? "Sem compromisso mensal" : "No monthly commitment"
                ];
                break;
            case 3: 
                totalSlots = 24;
                discountPercent = 0.05;
                margin = 3; 
                label = isPT ? "Sprint Trimestral" : "Quarterly Sprint";
                subLabel = isPT ? "Evolução Rápida" : "Quick level up";
                bonuses = [
                    isPT ? "24 Aulas Reservadas 1:1" : "24 Reserved 1:1 Slots",
                    isPT ? "3 Cancelamentos Flexíveis" : "3 Flexible Cancellations",
                    isPT ? "Suporte via WhatsApp" : "WhatsApp Support"
                ];
                break;
            case 12: 
                totalSlots = 96;
                discountPercent = 0.30;
                margin = 16;
                label = isPT ? "Academia Anual" : "Yearly Academy";
                subLabel = isPT ? "Domínio Nativo" : "Native Mastery Path";
                bonuses = [
                    isPT ? "96 Aulas Reservadas 1:1" : "96 Reserved 1:1 Slots",
                    isPT ? "16 Cancelamentos Flexíveis" : "16 Flexible Cancellations",
                    isPT ? "Roteiro Completo + IA" : "Full Roadmap + AI Suite",
                    isPT ? "Certificado Oficial de Proficiência" : "Official Proficiency Certificate",
                    isPT ? "Suporte Prioritário VIP" : "VIP Priority Support"
                ];
                break;
            case 6: 
            default:
                totalSlots = 48;
                discountPercent = 0.15;
                margin = 6;
                label = isPT ? "Programa Semestral" : "Semester Program";
                subLabel = isPT ? "Do zero à fluência" : "From stuck to fluent";
                bonuses = [
                    isPT ? "48 Aulas Reservadas 1:1" : "48 Reserved 1:1 Slots",
                    isPT ? "6 Cancelamentos Flexíveis" : "6 Flexible Cancellations",
                    isPT ? "Roteiro Personalizado + IA" : "Personalized Roadmap + AI",
                    isPT ? "Acesso Direto ao WhatsApp" : "Direct WhatsApp Access"
                ];
                break;
        }

        const standardTotalValue = teacher.hourlyRate * totalSlots;
        const finalPackagePrice = standardTotalValue * (1 - discountPercent);
        const savings = standardTotalValue - finalPackagePrice;
        const pricePerClass = finalPackagePrice / totalSlots;

        return {
            totalSlots,
            margin,
            label,
            subLabel,
            bonuses,
            discountLabel: discountPercent > 0 ? `${(discountPercent * 100).toFixed(0)}% OFF` : null,
            grossPrice: Math.ceil(finalPackagePrice),
            installmentPrice: Math.ceil((finalPackagePrice * 1.10) / 12),
            savings: Math.ceil(savings),
            pricePerClass: Math.floor(pricePerClass),
            standardRate: teacher.hourlyRate,
            classLabel: isPT ? (totalSlots === 1 ? "Sessão" : "Aulas") : (totalSlots === 1 ? "Session" : "Classes"),
            saveLabel: isPT ? "Economize" : "Save",
            perClassLabel: isPT ? "/aula" : "/class",
            dealButtonLabel: duration === 1 
                ? (isPT ? "Agendar Sessão Única" : "Book Single Session")
                : (isPT ? `Garantir Oferta de ${duration} Meses` : `Secure ${duration}-Month Deal`)
        };
    }, [teacher.hourlyRate, duration, language]);

    return (
        <div className={`bg-gradient-to-br from-gray-900 to-black border rounded-3xl p-1 relative overflow-hidden shadow-[0_0_40px_rgba(0,0,0,0.3)] mb-6 group transition-all duration-500 ${
            duration === 1 ? 'border-cyan-500/30' :
            duration === 6 ? 'border-yellow-600/50 shadow-[0_0_30px_rgba(234,179,8,0.15)]' : 
            duration === 12 ? 'border-purple-600/50 shadow-[0_0_30px_rgba(168,85,247,0.15)]' : 
            'border-gray-700'
        }`}>
            {packageStats.discountLabel && (
                <div className={`absolute top-4 right-0 text-white text-[10px] font-black px-3 py-1 uppercase tracking-widest z-20 ${
                    duration === 6 ? 'bg-red-600' : duration === 12 ? 'bg-cyan-600' : 'bg-gray-700'
                }`}>
                    {packageStats.discountLabel}
                </div>
            )}
            
            <div className="bg-gray-900/95 rounded-[22px] p-8 relative z-10 h-full flex flex-col">
                <div className="flex bg-black/40 p-1 rounded-2xl mb-8 border border-white/5 relative">
                    <button onClick={() => setDuration(1)} className={`flex-1 py-3 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all ${duration === 1 ? 'bg-white text-black shadow-xl' : 'text-gray-500 hover:text-white'}`}>Avulsa</button>
                    <button onClick={() => setDuration(3)} className={`flex-1 py-3 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all ${duration === 3 ? 'bg-white text-black shadow-xl' : 'text-gray-500 hover:text-white'}`}>3 Meses</button>
                    <button onClick={() => setDuration(6)} className={`flex-1 py-3 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all ${duration === 6 ? 'bg-yellow-500 text-black shadow-xl' : 'text-gray-500 hover:text-white'}`}>6 Meses</button>
                    <button onClick={() => setDuration(12)} className={`flex-1 py-3 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all ${duration === 12 ? 'bg-cyan-500 text-white shadow-xl' : 'text-gray-500 hover:text-white'}`}>1 Ano</button>
                </div>

                <div className="text-center mb-8">
                    <div className="flex items-center justify-center gap-3">
                        <span className="text-5xl font-black text-white font-orbitron tracking-tighter">R$ {packageStats.grossPrice}</span>
                    </div>
                    {duration !== 1 && (
                        <div className="flex justify-center items-center gap-2 mt-3">
                             <span className="bg-green-900/30 text-green-400 text-[10px] font-black px-3 py-1 rounded border border-green-800 uppercase tracking-widest">
                                {packageStats.saveLabel} R$ {packageStats.savings}
                            </span>
                            <span className="text-gray-600 text-xs line-through font-mono">R$ {packageStats.standardRate * packageStats.totalSlots}</span>
                        </div>
                    )}
                </div>

                <div className="bg-black/40 rounded-2xl p-5 border border-white/5 mb-8 flex justify-between items-center">
                    <div className="text-left">
                        <span className="block text-white font-black text-xl font-orbitron">{packageStats.totalSlots} {packageStats.classLabel}</span>
                        <span className="text-[10px] text-gray-500 uppercase font-bold tracking-[0.2em]">{packageStats.label}</span>
                    </div>
                    <div className="text-right">
                        <span className={`block font-black text-xl font-mono ${duration === 1 ? 'text-white' : 'text-cyan-400'}`}>
                            R$ {packageStats.pricePerClass}
                        </span>
                        <span className="text-[10px] text-gray-500 uppercase font-bold tracking-widest">Valor Unitário</span>
                    </div>
                </div>

                <div className="space-y-4 mb-8 flex-1 border-t border-white/5 pt-6">
                    {packageStats.bonuses.map((bonus, idx) => (
                        <div key={idx} className="flex items-start gap-3">
                            <div className="mt-1 bg-cyan-900/20 p-1 rounded-full text-cyan-400">
                                <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={4} d="M5 13l4 4L19 7" /></svg>
                            </div>
                            <p className="text-xs text-gray-300 font-black uppercase tracking-widest leading-relaxed">{bonus}</p>
                        </div>
                    ))}
                </div>

                <button 
                    onClick={() => onBook(duration)}
                    className={`w-full font-black py-5 rounded-2xl shadow-2xl transition-all transform hover:scale-[1.02] text-xs uppercase tracking-[0.3em] ${
                        duration === 1 ? 'bg-white text-black hover:bg-cyan-400' :
                        duration === 6 ? 'bg-yellow-500 text-black' :
                        duration === 12 ? 'bg-cyan-600 text-white' :
                        'bg-gray-800 text-white'
                    }`}
                >
                    {packageStats.dealButtonLabel}
                </button>
            </div>
        </div>
    );
};

export const TeacherProfileView: React.FC<TeacherProfileViewProps> = ({ 
  teacher, 
  onBook, 
  onBack,
  language
}) => {
  const isPT = language === 'PT';

  return (
    <div className="min-h-screen pt-32 px-4 max-w-7xl mx-auto pb-20 animate-fade-in font-sans">
        <button onClick={onBack} className="text-gray-500 hover:text-white mb-10 flex items-center gap-3 transition-colors uppercase font-black text-[10px] tracking-widest">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
            RE_ROUTING_TO_TERMINAL
        </button>

        <div className="grid lg:grid-cols-12 gap-12 relative">
            
            {/* Intel Side */}
            <div className="lg:col-span-7 space-y-10">
                <div className="bg-gray-900/50 border border-white/10 rounded-[3rem] p-10 flex flex-col md:flex-row gap-10 items-center md:items-start relative overflow-hidden">
                     <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-cyan-900/20 to-transparent"></div>
                     
                     <div className="relative z-10 shrink-0">
                        <div className="relative inline-block">
                            <img src={teacher.photoUrl} className="w-44 h-44 rounded-[3rem] border-4 border-white/10 object-cover shadow-2xl" alt={teacher.name} />
                            {teacher.verified && (
                                <div className="absolute bottom-0 right-0 z-20 translate-x-2 translate-y-2">
                                    <VerifiedBadge size="lg" />
                                </div>
                            )}
                        </div>
                     </div>

                     <div className="flex-1 text-center md:text-left relative z-10">
                         <div className="flex items-center justify-center md:justify-start gap-4 mb-4">
                            <span className="text-[10px] font-black bg-cyan-950 text-cyan-400 border border-cyan-800 px-3 py-1 rounded-full uppercase tracking-widest">ELITE_MENTOR</span>
                            <div className="flex text-yellow-500 text-xs">★ ★ ★ ★ ★</div>
                         </div>
                         <h1 className="text-4xl md:text-6xl font-black text-white mb-4 font-orbitron tracking-tighter uppercase leading-none">{teacher.name}</h1>
                         <p className="text-gray-400 text-lg leading-relaxed font-medium">
                             {teacher.bio}
                         </p>
                     </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                    <MetricCard label="Ranking Global" value={`#${Math.floor(Math.random() * 50) + 1}`} />
                    <MetricCard label="Sincronias" value={`${teacher.reviewCount}+`} />
                    <MetricCard label="Score IA" value="98%" />
                    <MetricCard label="HPC" value={`R$ ${teacher.hourlyRate}`} />
                </div>

                {teacher.introVideoUrl && (
                    <div className="bg-gray-900 border border-white/10 rounded-[3rem] overflow-hidden shadow-2xl group">
                        <div className="p-8 border-b border-white/5 flex justify-between items-center bg-black/40">
                             <h3 className="text-white font-black text-[10px] uppercase tracking-[0.3em]">NEURAL_INTRO_VISUAL</h3>
                             <span className="text-cyan-500 font-mono text-[10px]">ENCRYPTED_STREAM_V4</span>
                        </div>
                        <div className="relative aspect-video bg-black">
                        <video controls className="w-full h-full object-cover" poster={teacher.photoUrl}>
                            <source src={teacher.introVideoUrl} type="video/mp4" />
                        </video>
                        </div>
                    </div>
                )}
            </div>

            {/* Tactical Side (VALORES) */}
            <div className="lg:col-span-5">
                <div className="sticky top-32">
                    <h3 className="text-white font-black text-[11px] uppercase tracking-[0.4em] mb-6 ml-4">Planos de Sincronia</h3>
                    <ElitePackageCard teacher={teacher} onBook={onBook} language={language} />
                    
                    <div className="mt-8 p-8 bg-black/40 border border-white/5 rounded-[2.5rem]">
                        <p className="text-gray-600 text-[9px] font-black uppercase tracking-[0.3em] mb-4 text-center">Garantia Quântica</p>
                        <p className="text-gray-500 text-[10px] leading-relaxed text-center italic">
                            "Caso não haja sincronia neural (empatia) na primeira sessão de qualquer pacote, o estorno do saldo residual é processado instantaneamente."
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
  );
};

const MetricCard = ({ label, value }: { label: string; value: string }) => (
    <div className="bg-gray-900/50 border border-white/5 p-6 rounded-3xl text-center shadow-lg hover:border-cyan-500/30 transition-all">
        <p className="text-gray-500 text-[9px] font-black uppercase tracking-widest mb-1">{label}</p>
        <p className="text-2xl font-black text-white font-mono">{value}</p>
    </div>
);
