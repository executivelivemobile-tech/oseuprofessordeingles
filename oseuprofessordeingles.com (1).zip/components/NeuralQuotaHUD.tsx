
import React from 'react';
import { User } from '../types';

interface NeuralQuotaHUDProps {
    user: User;
    compact?: boolean;
}

export const NeuralQuotaHUD: React.FC<NeuralQuotaHUDProps> = ({ user, compact }) => {
    const { current, max, tier, efficiencyBonus } = user.neuralCapacity;
    const percentage = Math.min(100, (current / max) * 100);
    
    const themeColor = user.role === 'TEACHER' ? 'purple' : 'cyan';
    const accentHex = themeColor === 'purple' ? '#a855f7' : '#06b6d4';

    if (compact) {
        return (
            <div className="flex items-center gap-3 bg-black/40 border border-white/5 px-3 py-1.5 rounded-full">
                <div className="w-20 h-1.5 bg-gray-800 rounded-full overflow-hidden">
                    <div 
                        className={`h-full transition-all duration-1000 ${themeColor === 'purple' ? 'bg-purple-500' : 'bg-cyan-500'}`}
                        style={{ width: `${percentage}%` }}
                    ></div>
                </div>
                <span className="text-[10px] font-mono text-gray-400">{current}/{max} NS</span>
            </div>
        );
    }

    return (
        <div className="bg-gray-900/80 border border-white/10 rounded-2xl p-6 shadow-xl relative overflow-hidden group">
            {/* Background Glow Baseada no Mérito */}
            <div 
                className={`absolute -top-10 -right-10 w-32 h-32 blur-3xl opacity-20 transition-all group-hover:opacity-40`}
                style={{ backgroundColor: accentHex }}
            ></div>

            <div className="flex justify-between items-start mb-4">
                <div>
                    <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-500 mb-1">
                        Sincronização_Neural
                    </h4>
                    <div className="flex items-center gap-2">
                        <span className="text-2xl font-bold text-white font-orbitron">{current}</span>
                        <span className="text-xs text-gray-600 font-mono">/ {max} NS</span>
                    </div>
                </div>
                <div className={`px-2 py-1 rounded border text-[9px] font-black uppercase tracking-widest ${
                    tier === 1 ? 'border-gray-700 text-gray-500' : 
                    tier === 2 ? 'border-cyan-500 text-cyan-400 bg-cyan-950/30' : 
                    'border-purple-500 text-purple-400 bg-purple-950/30 animate-pulse'
                }`}>
                    {tier === 1 ? 'Standard_Node' : tier === 2 ? 'Advanced_Link' : 'Master_Neural_Core'}
                </div>
            </div>

            {/* Barra de Progresso Meritocrática */}
            <div className="relative h-2 bg-black rounded-full overflow-hidden border border-white/5 mb-4">
                <div 
                    className={`absolute top-0 left-0 h-full transition-all duration-1000 ease-out shadow-[0_0_15px_rgba(34,211,238,0.5)] ${
                        themeColor === 'purple' ? 'bg-gradient-to-r from-purple-700 to-fuchsia-500' : 'bg-gradient-to-r from-cyan-700 to-blue-500'
                    }`}
                    style={{ width: `${percentage}%` }}
                ></div>
            </div>

            <div className="flex justify-between items-center text-[9px] font-mono">
                <span className="text-gray-500">Eficiência de Produção</span>
                <span className="text-green-500">+{efficiencyBonus}% Ativo</span>
            </div>

            {/* Gatilho Psicológico: Meta de Evolução */}
            <div className="mt-4 pt-4 border-t border-white/5">
                <p className="text-[10px] text-gray-400 leading-relaxed italic">
                    {user.role === 'TEACHER' 
                        ? `Produza mais ${5 - (user.meritStats.materialsCreated % 5)} materiais para expandir sua quota neural.`
                        : `Complete mais ${3 - (user.meritStats.lessonsCompleted % 3)} lições para evoluir seu Tier.`}
                </p>
            </div>
        </div>
    );
};
