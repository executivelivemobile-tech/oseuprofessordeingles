
import React, { useState, useMemo } from 'react';
import { Hero3D } from './Hero3D';
import { CourseCard } from './Cards';
import { Course, User } from '../types';
import { MOCK_TEACHERS } from '../constants';

interface HomeViewProps {
    currentUser: User | null;
    courses: Course[];
    onNavigateTeacher: (id: string) => void;
    onNavigateCourse: (id: string) => void;
    onNavigateAllCourses: () => void;
    onFindTeacher: () => void;
    onStartSquad: () => void;
    favoriteIds: string[];
    onToggleFavorite: (id: string) => void;
    language: 'EN' | 'PT';
}

const ProtocolModal: React.FC<{ onClose: () => void }> = ({ onClose }) => (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/95 backdrop-blur-2xl animate-fade-in">
        <div className="max-w-4xl w-full bg-gray-950 border border-white/10 rounded-[3rem] p-8 md:p-16 shadow-[0_0_100px_rgba(34,211,238,0.2)] relative overflow-hidden font-sans">
            <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-cyan-500 to-purple-600"></div>
            <button onClick={onClose} className="absolute top-8 right-8 text-gray-500 hover:text-white transition-colors">
                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
            <div className="grid md:grid-cols-2 gap-12 items-center text-left">
                <div className="space-y-8">
                    <h2 className="text-4xl font-bold text-white font-orbitron tracking-tighter uppercase leading-tight">Protocolo de <br/><span className="text-cyan-400">Sincronia Neural</span></h2>
                    <div className="space-y-6">
                        <div className="flex gap-5">
                            <div className="w-12 h-12 bg-cyan-900/30 rounded-2xl flex items-center justify-center text-cyan-400 font-bold border border-cyan-800 shrink-0">1</div>
                            <div>
                                <h4 className="text-white font-bold mb-1 uppercase text-sm">O Arquiteto (Você)</h4>
                                <p className="text-gray-500 text-sm">Inicia o Squad. Com 3 convidados, seu curso é Mérito (Custo Zero).</p>
                            </div>
                        </div>
                        <div className="flex gap-5">
                            <div className="w-12 h-12 bg-purple-900/30 rounded-2xl flex items-center justify-center text-purple-400 font-bold border border-purple-800 shrink-0">2</div>
                            <div>
                                <h4 className="text-white font-bold mb-1 uppercase text-sm">O Time (Squad)</h4>
                                <p className="text-gray-500 text-sm">Seus amigos pagam apenas o valor rateado, reduzindo o custo em até 75%.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="bg-black/60 border border-white/5 rounded-[2.5rem] p-10 text-center relative">
                    <div className="w-20 h-20 bg-cyan-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-[0_0_40px_rgba(6,182,212,0.4)]">
                         <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                    </div>
                    <h3 className="text-2xl font-bold text-white mb-8">Conhecimento é uma rede.</h3>
                    <button onClick={onClose} className="w-full bg-white text-black py-4 rounded-2xl font-black uppercase text-xs tracking-widest hover:bg-cyan-400 transition-all">Sincronizar Agora</button>
                </div>
            </div>
        </div>
    </div>
);

const EliteHeroAd: React.FC<{ onStart: () => void }> = ({ onStart }) => {
    const [showProtocol, setShowProtocol] = useState(false);
    return (
        <div className="w-full max-w-7xl mx-auto px-4 mb-24 animate-fade-in relative z-10 font-sans">
            {showProtocol && <ProtocolModal onClose={() => setShowProtocol(false)} />}
            <div className="relative bg-gradient-to-br from-[#0a0a0a] via-black to-black border border-white/10 rounded-[3.5rem] p-8 md:p-16 overflow-hidden shadow-[0_0_100px_rgba(0,0,0,0.5)] group">
                <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-cyan-500/10 to-transparent pointer-events-none"></div>
                <div className="relative z-10 grid lg:grid-cols-2 gap-16 items-center">
                    <div className="space-y-10 text-left">
                        <div className="inline-flex items-center gap-3 bg-white/5 border border-white/10 px-5 py-2 rounded-full">
                            <span className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse shadow-[0_0_10px_rgba(34,211,238,0.8)]"></span>
                            <span className="text-[10px] font-black text-cyan-400 uppercase tracking-[0.4em]">Protocolo_Sincronia_Ativo</span>
                        </div>
                        <h1 className="text-5xl md:text-7xl font-bold text-white font-orbitron leading-[1] tracking-tighter">
                            Aprender sozinho <br/> 
                            <span className="text-transparent bg-clip-text bg-gradient-to-r from-gray-500 to-gray-700 italic">é primitivo.</span><br/>
                            <span className="text-white underline decoration-cyan-500/30 underline-offset-8">Squads</span> são o futuro.
                        </h1>
                        <p className="text-gray-400 text-xl max-w-xl leading-relaxed font-medium">
                            Construa sua rede, divida o investimento e lidere o Squad rumo à fluência quântica. Sua influência agora vale acesso integral.
                        </p>
                        <div className="flex flex-col sm:flex-row gap-6 pt-4">
                            <button onClick={onStart} className="bg-white text-black px-12 py-5 rounded-2xl font-black text-xs uppercase tracking-[0.3em] hover:bg-cyan-400 transition-all shadow-2xl active:scale-95">
                                Iniciar Minha Turma
                            </button>
                            <button onClick={() => setShowProtocol(true)} className="bg-transparent border border-white/10 text-white px-12 py-5 rounded-2xl font-black text-xs uppercase tracking-[0.3em] hover:bg-white/5 transition-all">
                                Ver Protocolo
                            </button>
                        </div>
                    </div>
                    <div className="relative hidden lg:block">
                        <div className="bg-gray-900/60 backdrop-blur-2xl border border-white/10 rounded-[3rem] p-12 shadow-2xl transform rotate-3 hover:rotate-0 transition-transform duration-700">
                             <div className="mb-10">
                                <p className="text-gray-500 text-[10px] font-black uppercase tracking-[0.2em] mb-2">Estado_da_Aliança</p>
                                <div className="flex justify-between items-end mb-4">
                                    <h3 className="text-white font-orbitron font-bold text-3xl">75% SYNC</h3>
                                    <span className="text-cyan-400 font-black text-xs tracking-widest">+1 REFORÇO</span>
                                </div>
                                <div className="h-4 bg-black rounded-full border border-white/5 p-1 relative overflow-hidden">
                                    <div className="h-full bg-gradient-to-r from-cyan-600 via-blue-500 to-cyan-400 rounded-full shadow-[0_0_20px_rgba(34,211,238,0.5)]" style={{ width: '75%' }}></div>
                                </div>
                             </div>
                             <div className="grid grid-cols-2 gap-8 border-t border-white/5 pt-8">
                                <div>
                                    <p className="text-gray-600 text-[9px] font-black uppercase mb-1">Custo_Normal</p>
                                    <p className="text-white font-mono text-xl line-through opacity-30 italic">R$ 240/h</p>
                                </div>
                                <div>
                                    <p className="text-cyan-500 text-[9px] font-black uppercase mb-1">Custo_Squad</p>
                                    <p className="text-cyan-400 font-mono text-3xl font-black tracking-tighter">R$ 60/h</p>
                                </div>
                             </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export const HomeView: React.FC<HomeViewProps> = ({ 
    currentUser,
    courses, 
    onNavigateTeacher, 
    onNavigateCourse, 
    onNavigateAllCourses,
    onStartSquad,
    favoriteIds,
    onToggleFavorite,
}) => {
    const premiumCourses = useMemo(() => courses.filter(c => c.price >= 400), [courses]);
    const miniCourses = useMemo(() => courses.filter(c => c.price < 400 && c.price >= 100), [courses]);
    const ebooks = useMemo(() => courses.filter(c => c.price < 100), [courses]);

    return (
    <div className="min-h-screen pt-20 flex flex-col font-sans">
      
      {/* 1. HERO 3D (O CARROSSEL NO TOPO) */}
      <section className="relative min-h-[85vh] flex flex-col items-center justify-center text-center px-4 overflow-hidden mb-12">
        <div className="z-10 max-w-4xl mx-auto mb-10 mt-10">
          <h2 className="text-xs font-black text-cyan-500 uppercase tracking-[0.5em] mb-4">Elite Education Node</h2>
          <h1 className="text-5xl md:text-7xl font-extrabold mb-6 tracking-tighter uppercase font-orbitron">
            CONECTE-SE COM <br/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600">A ELITE DO INGLÊS</span>
          </h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto font-medium">Os melhores mentores globais e treinamentos de alta performance em um único terminal.</p>
        </div>
        <div className="w-full z-10">
            <Hero3D onSelectTeacher={onNavigateTeacher} />
        </div>
      </section>

      {/* 2. ELITE HERO AD (O QUE FIZEMOS ABAIXO DO CARROSEL) */}
      <EliteHeroAd onStart={onStartSquad} />

      {/* 3. CURSOS PREMIUM */}
      <section className="py-24 bg-black border-t border-white/5">
          <div className="max-w-7xl mx-auto px-4">
              <div className="flex justify-between items-end mb-12">
                  <div className="text-left">
                      <h2 className="text-4xl font-bold text-white font-orbitron tracking-tighter uppercase mb-2">Arsenal Elite</h2>
                      <p className="text-gray-500 font-medium">Treinamentos completos de imersão total.</p>
                  </div>
                  <button onClick={onNavigateAllCourses} className="text-[10px] font-black uppercase tracking-widest text-cyan-400 hover:text-white transition-colors border-b border-cyan-400 pb-1">Ver Todos</button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
                  {premiumCourses.slice(0, 3).map(course => (
                    <CourseCard 
                        key={course.id} course={course} isFavorite={favoriteIds.includes(course.id)}
                        onToggleFavorite={(e) => { e.stopPropagation(); onToggleFavorite(course.id); }}
                        onClick={() => onNavigateCourse(course.id)}
                    />
                  ))}
              </div>
          </div>
      </section>

      {/* 4. MINI CURSOS */}
      <section className="py-24 bg-[#050505] border-y border-white/5">
          <div className="max-w-7xl mx-auto px-4">
              <div className="mb-12 text-left">
                  <h2 className="text-4xl font-bold text-white font-orbitron tracking-tighter uppercase mb-2">Micro_Sprints</h2>
                  <p className="text-gray-500 font-medium">Habilidades específicas desbloqueadas em tempo recorde.</p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                  {miniCourses.slice(0, 4).map(course => (
                    <CourseCard 
                        key={course.id} course={course} isFavorite={favoriteIds.includes(course.id)}
                        onToggleFavorite={(e) => { e.stopPropagation(); onToggleFavorite(course.id); }}
                        onClick={() => onNavigateCourse(course.id)}
                    />
                  ))}
              </div>
          </div>
      </section>

      {/* 5. EBOOKS E ATIVOS DIGITAIS */}
      <section className="py-24 bg-black">
          <div className="max-w-7xl mx-auto px-4">
              <div className="mb-12 text-left">
                  <h2 className="text-4xl font-bold text-white font-orbitron tracking-tighter uppercase mb-2">Knowledge_Assets</h2>
                  <p className="text-gray-500 font-medium">Manuais, guias e ativos de suporte para sua jornada.</p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                  {ebooks.slice(0, 4).map(course => (
                    <CourseCard 
                        key={course.id} course={course} isFavorite={favoriteIds.includes(course.id)}
                        onToggleFavorite={(e) => { e.stopPropagation(); onToggleFavorite(course.id); }}
                        onClick={() => onNavigateCourse(course.id)}
                    />
                  ))}
              </div>
          </div>
      </section>
    </div>
    );
};
