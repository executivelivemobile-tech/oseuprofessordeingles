
import React, { useState } from 'react';
import { User, DigitalAsset } from '../types';
import { NeuralQuotaHUD } from './NeuralQuotaHUD';
import { TeacherRevenueEngine } from './TeacherRevenueEngine';
import { AssetConverter } from './AssetConverter';
import { LessonGenerator } from './LessonGenerator';

type TeacherTab = 'REVENUE_FACTORY' | 'SQUAD_MANAGEMENT' | 'CALENDAR' | 'COURSE_STUDIO';

export const TeacherDashboard: React.FC<{ user: User }> = ({ user }) => {
  const [activeTab, setActiveTab] = useState<TeacherTab>('REVENUE_FACTORY');
  const [isConverterOpen, setIsConverterOpen] = useState(false);

  return (
    <div className="min-h-screen pt-24 px-6 max-w-[1600px] mx-auto pb-20 font-sans">
      <div className="mb-12 border-b border-gray-800 pb-8 flex flex-col md:flex-row justify-between items-end gap-6">
          <div>
              <div className="flex items-center gap-4 mb-2">
                  <h1 className="text-5xl font-black text-white font-orbitron tracking-tighter">TEACHER_CORE</h1>
                  <span className="bg-emerald-950 text-emerald-400 border border-emerald-800 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">Efficiency: High</span>
              </div>
              <p className="text-gray-500 uppercase text-xs tracking-[0.3em]">Transforme seu tempo em ativos digitais perpétuos.</p>
          </div>
          
          <div className="flex gap-2 bg-gray-900/80 p-1.5 rounded-2xl border border-white/5">
              {(['REVENUE_FACTORY', 'SQUAD_MANAGEMENT', 'CALENDAR', 'COURSE_STUDIO'] as TeacherTab[]).map(tab => (
                  <button 
                      key={tab}
                      onClick={() => setActiveTab(tab)}
                      className={`px-6 py-3 rounded-xl text-[10px] font-black tracking-widest uppercase transition-all ${
                          activeTab === tab ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-900/40' : 'text-gray-500 hover:text-white'
                      }`}
                  >
                      {tab.replace('_', ' ')}
                  </button>
              ))}
          </div>
      </div>

      <div className="animate-fade-in grid lg:grid-cols-12 gap-8">
          {/* Main Content Area */}
          <div className="lg:col-span-8 space-y-8">
              {activeTab === 'REVENUE_FACTORY' && (
                  <>
                      <TeacherRevenueEngine user={user} />
                      
                      <div className="bg-gray-900 border border-gray-800 rounded-[2.5rem] p-10 shadow-2xl relative overflow-hidden">
                          <div className="absolute top-0 right-0 p-10 opacity-5">
                              <svg className="w-40 h-40" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>
                          </div>
                          
                          <div className="flex justify-between items-center mb-8">
                              <h3 className="text-2xl font-bold text-white font-orbitron">Esteira de Produção IA</h3>
                              <button 
                                onClick={() => setIsConverterOpen(true)}
                                className="bg-emerald-600 hover:bg-emerald-500 text-white px-6 py-2.5 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all shadow-lg shadow-emerald-900/20"
                              >
                                + Novo Ativo Digital
                              </button>
                          </div>

                          <div className="grid md:grid-cols-2 gap-6">
                              <ProductionCard 
                                title="E-book: Tech English Mastery" 
                                status="LIVE" 
                                sales={12} 
                                revenue="R$ 574,80" 
                                icon="📚"
                              />
                              <ProductionCard 
                                title="Sprint de Áudio: Interview Prep" 
                                status="DRAFT" 
                                sales={0} 
                                revenue="R$ 0,00" 
                                icon="🎙️"
                              />
                          </div>
                      </div>
                  </>
              )}

              {activeTab === 'SQUAD_MANAGEMENT' && (
                  <div className="bg-gray-900 border border-gray-800 rounded-[2.5rem] p-10 text-center py-20">
                      <div className="w-20 h-20 bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-6 text-3xl">👥</div>
                      <h3 className="text-2xl font-bold text-white mb-2">Escalabilidade de Turma</h3>
                      <p className="text-gray-500 max-w-sm mx-auto mb-10">Crie Squads de 6 alunos para maximizar seu HPC em até 400%.</p>
                      <button className="bg-cyan-600 text-white px-8 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest">Abrir Vagas Squad</button>
                  </div>
              )}
          </div>

          {/* Sidebar Area */}
          <div className="lg:col-span-4 space-y-6">
              <NeuralQuotaHUD user={user} />
              
              <div className="bg-gradient-to-br from-gray-900 to-black border border-gray-800 rounded-[2.5rem] p-8 shadow-xl">
                  <h4 className="text-gray-500 font-black text-[10px] uppercase tracking-widest mb-6">Métricas de Performance Real</h4>
                  <div className="space-y-6">
                      <div className="flex justify-between items-center">
                          <span className="text-gray-400 text-sm">Hourly Profit Capacity</span>
                          <span className="text-xl font-mono font-bold text-emerald-400">R$ 240/h</span>
                      </div>
                      <div className="flex justify-between items-center">
                          <span className="text-gray-400 text-sm">Retenção de Alunos</span>
                          <span className="text-xl font-mono font-bold text-cyan-400">92%</span>
                      </div>
                      <div className="pt-6 border-t border-gray-800">
                          <p className="text-[10px] text-gray-500 leading-relaxed italic">
                              "Seu HPC aumentou 15% após o lançamento do último E-book via IA Macley."
                          </p>
                      </div>
                  </div>
              </div>
          </div>
      </div>

      {isConverterOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl">
              <div className="max-w-2xl w-full">
                  <AssetConverter lesson={{topic: 'Business English', level: 'B2'} as any} user={user} onComplete={() => setIsConverterOpen(false)} />
                  <button onClick={() => setIsConverterOpen(false)} className="mt-6 block mx-auto text-gray-500 font-black text-[10px] uppercase tracking-widest">Cancelar_Protocolo</button>
              </div>
          </div>
      )}
    </div>
  );
};

const ProductionCard = ({ title, status, sales, revenue, icon }: any) => (
    <div className="bg-black/40 border border-gray-800 p-6 rounded-3xl hover:border-cyan-500/30 transition-all cursor-pointer group">
        <div className="flex justify-between items-start mb-4">
            <span className="text-3xl">{icon}</span>
            <span className={`text-[9px] font-black px-2 py-0.5 rounded border ${
                status === 'LIVE' ? 'border-emerald-500 text-emerald-400 bg-emerald-950/30' : 'border-gray-700 text-gray-500'
            }`}>
                {status}
            </span>
        </div>
        <h4 className="text-white font-bold mb-4 group-hover:text-cyan-400 transition-colors">{title}</h4>
        <div className="flex justify-between items-end border-t border-gray-800 pt-4 mt-auto">
            <div>
                <p className="text-[10px] text-gray-500 uppercase font-black">Vendas</p>
                <p className="text-lg font-mono font-bold text-white">{sales}</p>
            </div>
            <div className="text-right">
                <p className="text-[10px] text-gray-500 uppercase font-black">Receita Líquida</p>
                <p className="text-lg font-mono font-bold text-emerald-400">{revenue}</p>
            </div>
        </div>
    </div>
);
