
import React, { useState } from 'react';
import { LessonPlan, User } from '../types';
import { convertLessonToEbook } from '../services/geminiService';

interface AssetConverterProps {
    lesson: LessonPlan;
    user: User;
    onComplete: (assetType: string) => void;
}

export const AssetConverter: React.FC<AssetConverterProps> = ({ lesson, user, onComplete }) => {
    const [isConverting, setIsConverting] = useState(false);
    const [result, setResult] = useState<string | null>(null);

    const handleConvert = async () => {
        setIsConverting(true);
        try {
            const ebook = await convertLessonToEbook(lesson, user);
            setResult(ebook || "Falha na conversão.");
            onComplete('EBOOK');
        } catch (e) {
            alert("Energia Neural insuficiente para esta operação complexa.");
        } finally {
            setIsConverting(false);
        }
    };

    return (
        <div className="bg-gray-900 border border-purple-500/30 rounded-2xl p-6 mt-6 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-10">
                <svg className="w-12 h-12 text-purple-500" fill="currentColor" viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/></svg>
            </div>
            
            <h3 className="text-white font-bold mb-2 flex items-center gap-2">
                <span className="w-2 h-2 bg-purple-500 rounded-full animate-ping"></span>
                Reciclagem de Ativos
            </h3>
            <p className="text-gray-400 text-xs mb-4">Transforme este plano de aula em um E-book estruturado para venda automática.</p>
            
            {!result ? (
                <button 
                    onClick={handleConvert}
                    disabled={isConverting}
                    className="w-full bg-purple-600 hover:bg-purple-500 text-white py-3 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all flex items-center justify-center gap-2"
                >
                    {isConverting ? (
                        <>
                            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                            Sintetizando Produto...
                        </>
                    ) : 'Gerar E-book do Plano'}
                </button>
            ) : (
                <div className="space-y-4 animate-fade-in">
                    <div className="bg-black/40 p-4 rounded-xl border border-gray-800 text-xs text-gray-300 font-serif leading-relaxed h-40 overflow-y-auto">
                        {result}
                    </div>
                    <button className="w-full bg-green-600 text-white py-2 rounded-lg text-[10px] font-bold uppercase">
                        Publicar no Marketplace
                    </button>
                </div>
            )}
        </div>
    );
};
