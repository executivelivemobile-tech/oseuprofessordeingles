
import React, { useState, useEffect } from 'react';
import { User, Squad, Teacher } from '../types';
import { MOCK_TEACHERS } from '../constants';
import { squadService } from '../services/squadService';

interface SquadHubProps {
    currentUser: User;
    activeSquads: Squad[];
    onNavigateTeacher: (id: string) => void;
    onShare: (code: string) => void;
}

export const SquadHub: React.FC<SquadHubProps> = ({ currentUser, activeSquads, onNavigateTeacher, onShare }) => {
    const [isCreating, setIsCreating] = useState(false);
    const [localSquads, setLocalSquads] = useState<Squad[]>(activeSquads);

    const handleCreate = (name: string, teacher: Teacher) => {
        const newSquad = squadService.createSquad(name, currentUser, teacher);
        setLocalSquads(prev => [...prev, newSquad]);
        setIsCreating(false);
    };

    return (
        <div className="min-h-screen pt-24 px-4 max-w-7xl mx-auto pb-20 animate-fade-in font-sans">
            <div className="flex flex-col md:flex-row justify-between items-end mb-10 border-b border-gray-800 pb-8 gap-6">
                <div>
                    <h1 className="text-4xl md:text-5xl font-bold text-white font-orbitron tracking-tighter">SQUAD_CONQUEST</h1>
                    <p className="text-purple-400 text-xs uppercase tracking-[0.2em] mt-2 font-black italic">Arquitetura de influência: Lidere seu time rumo ao topo.</p>
                </div>
                {!isCreating && (
                    <button 
                        onClick={() => setIsCreating(true)}
                        className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white px-8 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl shadow-purple-900/40 transition-all flex items-center gap-3 group"
                    >
                        <svg className="w-5 h-5 group-hover:scale-125 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 6v6m0 0v6m0-6h6m-6 0H6" /></svg>
                        INICIAR NOVA TURMA
                    </button>
                )}
            </div>

            {isCreating ? (
                <SquadCreationForm user={currentUser} onSubmit={handleCreate} onCancel={() => setIsCreating(false)} />
            ) : (
                <div className="grid lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-2 space-y-12">
                        {localSquads.length > 0 ? (
                            localSquads.map(squad => (
                                <SquadConquestCard key={squad.id} squad={squad} user={currentUser} onShare={() => onShare(squad.inviteCode)} />
                            ))
                        ) : (
                            <div className="bg-gray-900/30 border border-gray-800 border-dashed rounded-[3rem] p-20 text-center relative overflow-hidden group">
                                <div className="absolute inset-0 bg-purple-500/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                                <div className="w-24 h-24 bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-8 border border-white/5">
                                    <svg className="w-12 h-12 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                                </div>
                                <h3 className="text-2xl font-bold text-white mb-3 text-center">Nenhum Squad Ativo</h3>
                                <button onClick={() => setIsCreating(true)} className="bg-white text-black font-black text-xs uppercase tracking-widest px-10 py-4 rounded-2xl">Lançar Primeira Turma</button>
                            </div>
                        )}
                    </div>
                    <div className="lg:col-span-1">
                        <div className="bg-gradient-to-br from-gray-900 to-black border border-purple-900/30 rounded-[2.5rem] p-8 shadow-2xl sticky top-24">
                            <h4 className="text-white font-black text-[11px] uppercase tracking-[0.3em] mb-6 text-purple-500">Métricas de Influência</h4>
                            <div className="space-y-6">
                                <div className="bg-black/40 p-5 rounded-2xl border border-white/5">
                                    <p className="text-gray-500 text-[10px] font-black uppercase mb-1">Impacto Financeiro Gerado</p>
                                    <p className="text-2xl font-bold text-white font-mono">R$ 0,00</p>
                                </div>
                                <div className="bg-black/40 p-5 rounded-2xl border border-white/5">
                                    <p className="text-gray-500 text-[10px] font-black uppercase mb-1">Mentores Recrutados</p>
                                    <p className="text-2xl font-bold text-white font-mono">{localSquads.length}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

const SquadConquestCard: React.FC<{ squad: Squad; user: User; onShare: () => void }> = ({ squad, user, onShare }) => {
    const isActivated = squad.members.length >= squad.minToActivate;
    const inviteUrl = `https://oseuprofessordeingles.com/join/${squad.inviteCode}`;
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(inviteUrl)}&color=06b6d4&bgcolor=000`;

    return (
        <div className="bg-gray-950 border-2 border-gray-800 rounded-[3.5rem] overflow-hidden group transition-all hover:border-purple-500/50 shadow-2xl relative">
            <div className="bg-black/60 px-10 py-6 border-b border-white/5 flex justify-between items-center">
                 <div className="flex items-center gap-3">
                    <div className={`w-3 h-3 rounded-full ${isActivated ? 'bg-yellow-500 shadow-[0_0_15px_rgba(234,179,8,0.8)]' : 'bg-purple-500 animate-pulse'}`}></div>
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-[0.4em] font-mono">
                        {isActivated ? "ACESSO ELITE CONQUISTADO" : `AGUARDANDO REFORÇOS (${squad.members.length}/${squad.maxMembers})`}
                    </span>
                 </div>
            </div>

            <div className="p-12">
                <div className="grid md:grid-cols-12 gap-12">
                    <div className="md:col-span-8">
                        <h3 className="text-4xl font-bold text-white font-orbitron tracking-tighter mb-4">{squad.name}</h3>
                        <p className="text-gray-500 uppercase text-[10px] font-black tracking-widest mb-8">Mentor: {squad.teacherName}</p>
                        
                        <div className="flex gap-2 mb-12">
                            {[...Array(squad.maxMembers)].map((_, i) => (
                                <div key={i} className={`h-2 flex-1 rounded-full ${i < squad.members.length ? 'bg-cyan-500' : 'bg-gray-800'}`}></div>
                            ))}
                        </div>

                        <div className="flex flex-col sm:flex-row gap-4">
                            <button onClick={onShare} className="bg-white text-black px-8 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-cyan-400 transition-all flex items-center justify-center gap-3">
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1" /></svg>
                                Copiar Link de Convite
                            </button>
                            <button className="bg-gray-900 text-gray-400 px-8 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest border border-white/5">Ver Detalhes do Squad</button>
                        </div>
                    </div>

                    <div className="md:col-span-4 flex flex-col items-center justify-center border-l border-white/5 pl-12">
                         <div className="bg-white p-3 rounded-2xl mb-4 group-hover:scale-110 transition-transform">
                            <img src={qrUrl} alt="Invite QR" className="w-32 h-32" />
                         </div>
                         <p className="text-[9px] text-gray-600 uppercase font-black tracking-widest text-center leading-tight">Aponte a câmera para <br/> entrar no Squad instantaneamente</p>
                    </div>
                </div>
            </div>
        </div>
    );
};

const SquadCreationForm: React.FC<{ user: User; onSubmit: (name: string, t: Teacher) => void; onCancel: () => void }> = ({ user, onSubmit, onCancel }) => {
    const [name, setName] = useState('');
    const [selectedTeacher, setSelectedTeacher] = useState<Teacher | null>(null);

    return (
        <div className="bg-gray-950 border border-gray-800 rounded-[4rem] p-12 animate-slide-up max-w-4xl mx-auto shadow-2xl">
            <h2 className="text-3xl font-bold text-white font-orbitron mb-10 text-center uppercase tracking-widest">Nova Missão Coletiva</h2>
            
            <div className="space-y-8">
                <div>
                    <label className="block text-[10px] text-gray-500 font-black uppercase mb-3 ml-2 tracking-widest">Nome do Squad</label>
                    <input 
                        value={name} onChange={e => setName(e.target.value)}
                        placeholder="Ex: Future Tech Squad"
                        className="w-full bg-black border border-white/10 rounded-2xl px-6 py-4 text-white focus:border-cyan-500 outline-none"
                    />
                </div>

                <div>
                    <label className="block text-[10px] text-gray-500 font-black uppercase mb-3 ml-2 tracking-widest">Escolha o Mentor</label>
                    <div className="grid md:grid-cols-2 gap-4">
                        {MOCK_TEACHERS.map(t => (
                            <button 
                                key={t.id}
                                onClick={() => setSelectedTeacher(t)}
                                className={`flex items-center gap-4 p-5 rounded-2xl border transition-all text-left ${selectedTeacher?.id === t.id ? 'bg-cyan-900/20 border-cyan-500' : 'bg-black border-white/5 hover:bg-gray-900'}`}
                            >
                                <img src={t.photoUrl} className="w-12 h-12 rounded-xl object-cover" alt={t.name} />
                                <div>
                                    <h4 className="text-white font-bold text-sm leading-none">{t.name}</h4>
                                    <p className="text-[10px] text-gray-500 uppercase mt-1">{t.niche[0]}</p>
                                </div>
                            </button>
                        ))}
                    </div>
                </div>

                <div className="pt-6 flex gap-4">
                    <button onClick={onCancel} className="flex-1 py-4 text-gray-500 font-black uppercase text-[10px] tracking-widest">Cancelar</button>
                    <button 
                        disabled={!name || !selectedTeacher}
                        onClick={() => onSubmit(name, selectedTeacher!)}
                        className="flex-[2] bg-white text-black py-4 rounded-2xl font-black uppercase text-[10px] tracking-widest hover:bg-cyan-400 disabled:opacity-30 transition-all"
                    >
                        Arquitetar Squad Agora
                    </button>
                </div>
            </div>
        </div>
    );
};
