
import React from 'react';
import { User } from '../types';

interface CreditStoreProps {
    user: User;
    onClose: () => void;
    onPurchase: (amount: number) => void;
}

export const CreditStore: React.FC<CreditStoreProps> = ({ user, onClose, onPurchase }) => {
    const packages = [
        { sparks: 100, price: 29, label: 'Starter Spark', color: 'cyan' },
        { sparks: 500, price: 99, label: 'Brain Surge', color: 'purple', popular: true },
        { sparks: 2000, price: 299, label: 'Neural Overlord', color: 'red' },
    ];

    return (
        <div className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-2xl flex items-center justify-center p-4">
            <div className="max-w-4xl w-full">
                <div className="text-center mb-12">
                    <h2 className="text-4xl font-bold text-white font-orbitron mb-4">RECARGA_SINÁPTICA</h2>
                    <p className="text-gray-400">Sua capacidade neural está no limite. Expanda sua consciência digital.</p>
                </div>

                <div className="grid md:grid-cols-3 gap-6">
                    {packages.map((pkg) => (
                        <div 
                            key={pkg.label}
                            className={`bg-gray-900 border-2 rounded-[2rem] p-8 flex flex-col items-center transition-all hover:scale-105 relative ${
                                pkg.popular ? 'border-purple-600 shadow-purple-900/20' : 'border-gray-800'
                            }`}
                        >
                            {pkg.popular && (
                                <span className="absolute -top-4 bg-purple-600 text-white px-4 py-1 rounded-full text-[10px] font-black uppercase">Mais Eficiente</span>
                            )}
                            <h3 className="text-white font-bold text-lg mb-1">{pkg.label}</h3>
                            <div className="text-4xl font-black text-white mb-6 font-mono">
                                {pkg.sparks} <span className="text-xs text-gray-500">NS</span>
                            </div>
                            <div className="text-2xl font-bold text-cyan-400 mb-8">R$ {pkg.price}</div>
                            <button 
                                onClick={() => onPurchase(pkg.sparks)}
                                className={`w-full py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all ${
                                    pkg.color === 'purple' ? 'bg-purple-600 hover:bg-purple-500' : 'bg-gray-800 hover:bg-gray-700'
                                }`}
                            >
                                Adquirir Energia
                            </button>
                        </div>
                    ))}
                </div>

                <button 
                    onClick={onClose}
                    className="mt-12 block mx-auto text-gray-500 hover:text-white text-xs font-bold uppercase tracking-widest"
                >
                    Voltar ao Terminal
                </button>
            </div>
        </div>
    );
};
