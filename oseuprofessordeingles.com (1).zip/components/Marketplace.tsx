
import React, { useState, useMemo, useEffect } from 'react';
import { Teacher, Course, User } from '../types';
import { TeacherCard, CourseCard } from './Cards';
import { CourseCheckoutModal } from './CourseCheckoutModal';

interface MarketplaceProps {
    type: 'teacher' | 'course';
    items: (Teacher | Course)[];
    onNavigate: (id: string) => void;
    favoriteIds: string[];
    onToggleFavorite: (id: string) => void;
    currentUser: User | null;
    language: 'EN' | 'PT';
}

export const Marketplace: React.FC<MarketplaceProps> = ({ 
    type, 
    items, 
    onNavigate, 
    favoriteIds, 
    onToggleFavorite,
    currentUser,
    language
}) => {
    const [searchQuery, setSearchQuery] = useState('');
    const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
    const isPT = language === 'PT';

    const filteredItems = useMemo(() => {
        return items.filter(item => {
            const name = 'name' in item ? item.name : item.title;
            return name.toLowerCase().includes(searchQuery.toLowerCase());
        });
    }, [items, searchQuery]);

    return (
        <div className="min-h-screen pt-24 px-4 max-w-7xl mx-auto pb-20 font-sans">
            <div className="mb-12">
                <h2 className="text-5xl font-black text-white mb-4 font-orbitron tracking-tighter uppercase">
                    {type === 'teacher' ? 'Recrutar Mentores' : 'Arsenal de Conhecimento'}
                </h2>
                <div className="relative max-w-xl">
                    <input 
                        type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder={isPT ? "Buscar por nome ou especialidade..." : "Search..."}
                        className="w-full bg-gray-900 border border-white/10 rounded-2xl px-6 py-4 text-white focus:border-cyan-500 outline-none transition-all"
                    />
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                {filteredItems.map(item => (
                    type === 'teacher' ? (
                        <TeacherCard 
                            key={item.id} teacher={item as Teacher} isFavorite={favoriteIds.includes(item.id)}
                            onToggleFavorite={(e) => { e.stopPropagation(); onToggleFavorite(item.id); }}
                            onClick={() => onNavigate(item.id)}
                        />
                    ) : (
                        <CourseCard 
                            key={item.id} course={item as Course} isFavorite={favoriteIds.includes(item.id)}
                            onToggleFavorite={(e) => { e.stopPropagation(); onToggleFavorite(item.id); }}
                            onClick={() => setSelectedCourse(item as Course)}
                        />
                    )
                ))}
            </div>

            {selectedCourse && currentUser && (
                <CourseCheckoutModal 
                    course={selectedCourse} 
                    user={currentUser}
                    onClose={() => setSelectedCourse(null)} 
                    onConfirm={() => { setSelectedCourse(null); onNavigate(selectedCourse.id); }}
                    language={language}
                />
            )}
        </div>
    );
};
