
import React, { useState, useMemo } from 'react';
import { User, Squad, SquadStatus } from '../types';

interface SquadFormationProps {
    user: User;
    activeSquads: Squad[];
    onCreateSquad: () => void;
    onShareSquad: (squadId: string) => void;
}

export const SquadFormation: React.FC<SquadFormationProps> = ({ user, activeSquads, onCreateSquad, onShareSquad }) => {
    return (
        <div className="space-y-8 animate-fade-in">
            <div className="flex justify-between items-end border-b border-gray-800 pb-6">
                <div>
                    <h2 className="text-3xl font-bold text-white font-orbitron tracking-tight uppercase">CENTRAL_DE_CONQUISTA</h2>
                    <p className="text-purple-400 text-xs uppercase tracking-[0.2em] mt-1 font-black italic">Transforme sua rede em um legado de conhecimento.</p>
                </div>
                <button 
                    onClick={onCreateSquad}
                    className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white px-6 py-2.5 rounded-xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-purple-900/40 transition-all"
                >
                    + Liderar Nova Missão
                </button>
            </div>

            {activeSquads.length === 0 ? (
                <div className="bg-gray-900/50 border border-gray-800 border-dashed rounded-3xl p-12 text-center relative overflow-hidden group">
                    <div className="absolute inset-0 bg-purple-500/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                    <div className="w-16 h-16 bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-6 border border-white/5">
                         <svg className="w-8 h-8 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                    </div>
                    <p className="text-gray-500 text-sm max-w-xs mx-auto mb-6 leading-relaxed font-medium">Você ainda não lidera nenhum Squad. Inicie uma formação para <span className="text-purple-400 font-bold">conquistar seu acesso elite</span>.</p>
                    <button onClick={onCreateSquad} className="bg-white/10 hover:bg-white/20 text-white px-8 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest border border-white/10 transition-all">Iniciar Protocolo</button>
                </div>
            ) : (
                <div className="grid md:grid-cols-2 gap-6">
                    {activeSquads.map(squad => (
                        <SquadCard key={squad.id} squad={squad} onShare={() => onShareSquad(squad.id)} />
                    ))}
                </div>
            )}
        </div>
    );
};

const SquadCard: React.FC<{ squad: Squad; onShare: () => void }> = ({ squad, onShare }) => {
    const currentMembers = squad.members.length;
    const progress = (currentMembers / squad.maxMembers) * 100;
    const isActivated = currentMembers >= squad.minToActivate;
    
    const statusLabels = [
        { count: 1, label: 'Liderança Ativa', color: 'gray' },
        { count: 2, label: 'Aliança em Formação', color: 'blue' },
        { count: 3, label: 'Pressão Máxima', color: 'purple' },
        { count: 4, label: 'CONQUISTA REALIZADA', color: 'green' },
    ];

    const currentMilestone = useMemo(() => {
        return statusLabels.find(s => s.count === currentMembers) || statusLabels[3];
    }, [currentMembers]);

    return (
        <div className="bg-gray-900 border border-gray-800 rounded-[2.5rem] p-8 relative overflow-hidden group transition-all hover:border-purple-500/40 shadow-xl">
            {/* Ambient Victory Glow */}
            <div 
                className={`absolute -right-20 -top-20 w-48 h-48 blur-[80px] opacity-10 transition-colors duration-1000 ${
                    isActivated ? 'bg-yellow-500 opacity-20' : 'bg-purple-500'
                }`}
            ></div>

            <div className="flex justify-between items-start mb-8 relative z-10">
                <div>
                    <h4 className="text-white font-bold text-xl font-orbitron tracking-tight">{squad.name}</h4>
                    <p className="text-[9px] text-gray-500 uppercase tracking-[0.3em] mt-1">Mentor: {squad.teacherName}</p>
                </div>
                <div className={`px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest border ${
                    isActivated ? 'bg-yellow-500/10 border-yellow-500/50 text-yellow-500' : 'bg-purple-900/20 border-purple-500 text-purple-400'
                }`}>
                    {currentMilestone.label}
                </div>
            </div>

            {/* Victory Meter */}
            <div className="mb-10 relative z-10">
                <div className="flex justify-between text-[10px] font-black text-gray-500 uppercase mb-3 tracking-widest">
                    <span>Sincronia Neural</span>
                    <span className={isActivated ? 'text-yellow-500' : 'text-purple-400'}>{currentMembers}/{squad.maxMembers} Mentes</span>
                </div>
                <div className="h-2 bg-black rounded-full border border-white/5 overflow-hidden">
                    <div 
                        className={`h-full transition-all duration-1000 ease-out shadow-[0_0_15px_rgba(168,85,247,0.4)] ${
                            isActivated ? 'bg-gradient-to-r from-yellow-600 to-yellow-400' : 'bg-gradient-to-r from-purple-600 to-blue-500'
                        }`}
                        style={{ width: `${progress}%` }}
                    ></div>
                </div>
            </div>

            {/* Reward Display: Focusing on Status/Victory */}
            <div className={`rounded-3xl p-6 border transition-all duration-700 mb-8 relative overflow-hidden ${
                isActivated ? 'bg-gradient-to-br from-yellow-600/10 to-black border-yellow-500/30' : 'bg-black/40 border-white/5'
            }`}>
                <p className="text-[9px] text-gray-500 uppercase font-black mb-3 tracking-[0.2em] relative z-10">Seu Reconhecimento de Liderança</p>
                <div className="flex items-center gap-4 relative z-10">
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all ${
                        isActivated ? 'bg-yellow-500 text-black shadow-[0_0_20px_rgba(234,179,8,0.4)]' : 'bg-gray-800 text-gray-600'
                    }`}>
                        <svg className="w-7 h-7" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"/></svg>
                    </div>
                    <div>
                        <p className={`text-sm font-black uppercase tracking-tight ${isActivated ? 'text-white' : 'text-gray-500'}`}>
                            {isActivated ? 'ACESSO ELITE CONQUISTADO' : 'Rumo à Vitória Coletiva'}
                        </p>
                        <p className="text-[10px] text-gray-600 leading-relaxed font-medium">
                            {isActivated 
                                ? 'Sua missão foi concluída. O curso agora é seu por direito de liderança.' 
                                : `Faltam ${squad.minToActivate - currentMembers} reforço(s) para liberar seu acesso integral.`
                            }
                        </p>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
                <button 
                    onClick={onShare}
                    className="bg-white hover:bg-purple-500 hover:text-white text-black py-4 rounded-2xl font-black text-[10px] uppercase tracking-[0.3em] transition-all flex items-center justify-center gap-3 active:scale-95 shadow-xl"
                >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" /></svg>
                    CONVOCAR
                </button>
                <button className="bg-gray-800 text-gray-400 hover:text-white py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all border border-white/5">
                    VER_SQUAD
                </button>
            </div>
        </div>
    );
};
