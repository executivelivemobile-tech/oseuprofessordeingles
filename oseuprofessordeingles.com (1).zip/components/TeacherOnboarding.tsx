
import React, { useState } from 'react';
import { Teacher } from '../types';

interface TeacherOnboardingProps {
  onSubmit: (teacherData: Partial<Teacher>) => void;
  onCancel: () => void;
}

export const TeacherOnboarding: React.FC<TeacherOnboardingProps> = ({ onSubmit, onCancel }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    location: '',
    bio: '',
    accent: 'International',
    hourlyRate: 60,
    pixKey: '', // NOVO: Campo Crítico
    nicheInput: '',
    photoUrl: 'https://picsum.photos/seed/new/200/200',
    introVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4'
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleNext = () => setStep(prev => prev + 1);
  const handleBack = () => setStep(prev => prev - 1);

  const handleSubmit = () => {
    const niches = formData.nicheInput.split(',').map(s => s.trim()).filter(s => s.length > 0);
    
    onSubmit({
      name: formData.name,
      location: formData.location,
      bio: formData.bio,
      accent: formData.accent as any,
      hourlyRate: Number(formData.hourlyRate),
      pixKey: formData.pixKey,
      niche: niches.length > 0 ? niches : ['General English'],
      photoUrl: formData.photoUrl,
      introVideoUrl: formData.introVideoUrl,
    });
  };

  return (
    <div className="min-h-screen pt-24 px-4 max-w-3xl mx-auto pb-20">
      <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white uppercase font-orbitron tracking-tighter">Recrutamento_Elite</h1>
            <p className="text-gray-400">Step {step} of 3</p>
          </div>
          <button onClick={onCancel} className="text-gray-500 hover:text-white">Cancel</button>
      </div>

      <div className="w-full h-1 bg-gray-800 rounded-full mb-8">
          <div className={`h-full bg-cyan-500 rounded-full transition-all duration-500`} style={{ width: `${(step / 3) * 100}%` }}></div>
      </div>

      <div className="bg-gray-900 border border-gray-800 rounded-[2.5rem] p-8 md:p-12 shadow-2xl relative overflow-hidden">
          
          {step === 1 && (
              <div className="space-y-6 animate-fade-in">
                  <h2 className="text-xl font-bold text-white mb-8 font-orbitron">IDENTIDADE_DO_MESTRE</h2>
                  
                  <div className="space-y-1">
                      <label className="block text-[10px] text-gray-500 uppercase font-black ml-2 tracking-widest">Nome Completo</label>
                      <input name="name" value={formData.name} onChange={handleChange} className="w-full bg-black border border-white/10 rounded-2xl px-5 py-4 text-white focus:border-cyan-500 outline-none" />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                        <label className="block text-[10px] text-gray-500 uppercase font-black ml-2 tracking-widest">Localização</label>
                        <input name="location" value={formData.location} onChange={handleChange} className="w-full bg-black border border-white/10 rounded-2xl px-5 py-4 text-white focus:border-cyan-500 outline-none" />
                    </div>
                    <div className="space-y-1">
                        <label className="block text-[10px] text-gray-500 uppercase font-black ml-2 tracking-widest">Sotaque Nativo</label>
                        <select name="accent" value={formData.accent} onChange={handleChange} className="w-full bg-black border border-white/10 rounded-2xl px-5 py-4 text-white focus:border-cyan-500 outline-none appearance-none">
                            <option value="International">International</option>
                            <option value="USA">USA</option>
                            <option value="UK">UK</option>
                        </select>
                    </div>
                  </div>

                  <div className="flex justify-end pt-4">
                      <button onClick={handleNext} disabled={!formData.name} className="bg-white text-black px-10 py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-cyan-400 transition-all shadow-xl">
                          Protocolo_Seguinte
                      </button>
                  </div>
              </div>
          )}

          {step === 2 && (
              <div className="space-y-8 animate-fade-in">
                  <h2 className="text-xl font-bold text-white mb-4 font-orbitron">FINANCEIRO_&_EXPERTISE</h2>

                  <div className="grid md:grid-cols-2 gap-6">
                      <div className="space-y-1">
                          <label className="block text-[10px] text-gray-500 uppercase font-black ml-2 tracking-widest">Valor Hora (R$)</label>
                          <input type="number" name="hourlyRate" value={formData.hourlyRate} onChange={handleChange} className="w-full bg-black border border-white/10 rounded-2xl px-5 py-4 text-white focus:border-cyan-500 outline-none font-mono" />
                      </div>
                      <div className="space-y-1">
                          <label className="block text-[10px] text-emerald-500 uppercase font-black ml-2 tracking-[0.2em] animate-pulse">Chave PIX (Para Recebimento)</label>
                          <input required name="pixKey" placeholder="CPF, E-mail ou Aleatória" value={formData.pixKey} onChange={handleChange} className="w-full bg-black border border-emerald-500/30 rounded-2xl px-5 py-4 text-white focus:border-emerald-500 outline-none font-mono" />
                      </div>
                  </div>

                  <div className="bg-emerald-950/20 p-6 rounded-2xl border border-emerald-900/30">
                      <p className="text-[10px] text-emerald-500 font-black uppercase mb-1 tracking-widest flex items-center gap-2">
                          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"/></svg>
                          Custódia de Recebíveis
                      </p>
                      <p className="text-gray-500 text-[10px] leading-relaxed">
                          Sua chave PIX será utilizada para o saque diário compulsório. Certifique-se de que a chave pertence à mesma titularidade do seu CPF cadastrado.
                      </p>
                  </div>

                  <div className="flex justify-between pt-4">
                      <button onClick={handleBack} className="text-gray-500 hover:text-white uppercase font-black text-xs">Voltar</button>
                      <button onClick={handleNext} disabled={!formData.pixKey} className="bg-white text-black px-10 py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-cyan-400 transition-all shadow-xl disabled:opacity-30">
                          Confirmar_Dados
                      </button>
                  </div>
              </div>
          )}

          {step === 3 && (
              <div className="space-y-8 animate-fade-in text-center">
                  <div className="w-20 h-20 bg-cyan-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-[0_0_40px_rgba(8,145,178,0.4)]">
                       <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>
                  </div>
                  <h2 className="text-2xl font-bold text-white font-orbitron uppercase tracking-tighter">VALIDAÇÃO_PENDENTE</h2>
                  <p className="text-gray-400 text-sm max-w-sm mx-auto leading-relaxed">
                      Seu perfil entrará em análise neural. Chave PIX detectada: <span className="text-emerald-500 font-mono font-bold">{formData.pixKey}</span>
                  </p>
                  
                  <div className="flex flex-col gap-4 pt-8">
                      <button onClick={handleSubmit} className="w-full bg-cyan-600 hover:bg-cyan-500 text-white py-5 rounded-3xl font-black text-xs uppercase tracking-widest shadow-2xl transition-all">
                          Submeter para Auditoria
                      </button>
                      <button onClick={handleBack} className="text-gray-500 hover:text-white text-xs uppercase font-black">Revisar_Protocolos</button>
                  </div>
              </div>
          )}

      </div>
    </div>
  );
};
