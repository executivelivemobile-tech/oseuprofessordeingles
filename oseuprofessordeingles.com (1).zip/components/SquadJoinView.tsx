
import React from 'react';
import { Squad, User } from '../types';

interface SquadJoinViewProps {
    squad: Squad;
    onJoin: () => void;
    onLogin: () => void;
    currentUser: User | null;
}

export const SquadJoinView: React.FC<SquadJoinViewProps> = ({ squad, onJoin, onLogin, currentUser }) => {
    const leader = squad.members.find(m => m.isLeader);
    const isFull = squad.members.length >= squad.maxMembers;
    
    return (
        <div className="min-h-screen bg-black flex flex-col items-center justify-center p-6 animate-fade-in font-sans selection:bg-cyan-500">
            {/* Background cinematic */}
            <div className="absolute inset-0 overflow-hidden pointer-events-none">
                <div className="absolute top-1/4 left-1/4 w-[40rem] h-[40rem] bg-cyan-900/20 rounded-full blur-[160px] animate-pulse"></div>
                <div className="absolute bottom-1/4 right-1/4 w-[35rem] h-[35rem] bg-purple-900/15 rounded-full blur-[140px] animate-pulse-slow"></div>
                <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10"></div>
            </div>

            <div className="max-w-2xl w-full relative z-10">
                <div className="bg-gray-900/80 backdrop-blur-2xl border border-white/10 rounded-[3.5rem] p-12 md:p-20 shadow-[0_0_80px_rgba(0,0,0,0.8)] text-center relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-cyan-600 to-purple-600"></div>

                    <div className="relative inline-block mb-12">
                        <div className="absolute inset-0 border-4 border-cyan-500 rounded-[2.5rem] animate-ping opacity-20"></div>
                        <img src={leader?.avatarUrl} className="w-32 h-32 rounded-[2.5rem] border-4 border-cyan-500 shadow-2xl object-cover relative z-10" alt="Leader" />
                        <div className="absolute -bottom-3 -right-3 bg-cyan-600 text-white p-3 rounded-2xl z-20 shadow-xl border border-cyan-400">
                             <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" /></svg>
                        </div>
                    </div>

                    <h2 className="text-4xl md:text-5xl font-bold text-white mb-8 font-orbitron tracking-tighter uppercase leading-tight">
                        <span className="text-cyan-400">{leader?.name.split(' ')[0]}</span> convocou você.
                    </h2>
                    
                    <p className="text-gray-400 text-xl mb-12 leading-relaxed font-medium">
                        Ele está arquitetando o Squad <strong className="text-white">"{squad.name}"</strong> com o mestre <strong>{squad.teacherName}</strong>. Juntos, vocês desbloqueiam o benefício coletivo e reduzem o custo individual drasticamente.
                    </p>

                    <div className="bg-black/50 border border-white/5 rounded-[2.5rem] p-10 mb-12 text-left relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-10 opacity-5 pointer-events-none">
                             <svg className="w-24 h-24 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>
                        </div>
                        
                        <div className="flex justify-between items-center mb-6">
                            <span className="text-xs text-gray-500 uppercase font-black tracking-[0.3em]">Meta de Sincronia</span>
                            <span className="text-white font-black font-mono text-xl">{squad.members.length}/{squad.maxMembers} Mentes</span>
                        </div>
                        
                        <div className="w-full h-3 bg-gray-800 rounded-full overflow-hidden p-0.5 border border-white/5">
                            <div 
                                className="h-full bg-gradient-to-r from-cyan-600 to-blue-500 rounded-full transition-all duration-1000 shadow-[0_0_15px_rgba(6,182,212,0.5)]" 
                                style={{ width: `${(squad.members.length / squad.maxMembers) * 100}%` }}
                            ></div>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4 mt-8">
                            <div className="flex items-center gap-3">
                                <div className="w-2 h-2 rounded-full bg-green-500"></div>
                                <span className="text-[10px] text-gray-400 uppercase font-bold tracking-widest">Estudo Colaborativo</span>
                            </div>
                            <div className="flex items-center gap-3">
                                <div className="w-2 h-2 rounded-full bg-cyan-500"></div>
                                <span className="text-[10px] text-gray-400 uppercase font-bold tracking-widest">Split de Investimento</span>
                            </div>
                        </div>
                    </div>

                    {isFull ? (
                        <div className="bg-red-900/20 border border-red-500/30 p-6 rounded-2xl">
                             <p className="text-red-400 font-bold uppercase text-xs tracking-widest">Este Squad atingiu a capacidade máxima neural.</p>
                        </div>
                    ) : (
                        currentUser ? (
                            <button 
                                onClick={onJoin}
                                className="w-full bg-white hover:bg-cyan-400 text-black py-6 rounded-3xl font-black uppercase tracking-[0.4em] text-xs shadow-2xl transition-all transform hover:scale-[1.02] active:scale-95 flex items-center justify-center gap-4"
                            >
                                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>
                                Confirmar Entrada no Squad
                            </button>
                        ) : (
                            <button 
                                onClick={onLogin}
                                className="w-full bg-cyan-600 hover:bg-cyan-500 text-white py-6 rounded-3xl font-black uppercase tracking-[0.4em] text-xs shadow-2xl shadow-cyan-900/40 transition-all flex items-center justify-center gap-4"
                            >
                                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" /></svg>
                                Conectar para Participar
                            </button>
                        )
                    )}
                    
                    <p className="mt-12 text-[9px] text-gray-700 uppercase font-black tracking-[0.5em] font-mono">Protocolo: Collective_Growth_v2.1_Neural_Link</p>
                </div>
            </div>
        </div>
    );
}
