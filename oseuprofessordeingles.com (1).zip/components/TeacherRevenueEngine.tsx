
import React, { useState } from 'react';
import { User } from '../types';

export const TeacherRevenueEngine: React.FC<{ user: User }> = ({ user }) => {
    const [isFeeBoosterActive, setIsFeeBoosterActive] = useState(false);

    return (
        <div className="space-y-6 animate-fade-in">
            <div className="bg-gradient-to-br from-gray-900 via-black to-gray-900 border border-emerald-500/30 rounded-[2.5rem] p-10 shadow-2xl relative overflow-hidden group">
                {/* Glow de Dinheiro */}
                <div className="absolute -top-24 -right-24 w-64 h-64 bg-emerald-500/10 blur-[100px] group-hover:bg-emerald-500/20 transition-all duration-1000"></div>

                <div className="relative z-10">
                    <div className="flex justify-between items-start mb-8">
                        <div>
                            <h2 className="text-emerald-400 font-black text-[10px] uppercase tracking-[0.4em] mb-2">Painel de Escalabilidade</h2>
                            <p className="text-4xl font-bold text-white font-orbitron tracking-tighter">R$ {user.meritStats.passiveRevenue.toFixed(2)}</p>
                            <p className="text-gray-500 text-xs mt-1 uppercase font-bold tracking-widest">Receita Passiva (Este Mês)</p>
                        </div>
                        <div className="text-right">
                            <span className="text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-800 px-3 py-1 rounded-full font-black uppercase tracking-widest">HPC: R$ 340/h</span>
                        </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                        <div className="bg-black/60 border border-white/5 p-6 rounded-[2rem] hover:border-emerald-500/30 transition-all">
                            <p className="text-gray-500 text-[10px] font-black uppercase mb-4 tracking-widest">Protocolo de Taxa</p>
                            <div className="flex justify-between items-center mb-6">
                                <span className="text-white text-sm">Fee da Plataforma</span>
                                <span className={`text-2xl font-mono font-bold ${isFeeBoosterActive ? 'text-emerald-400' : 'text-gray-400'}`}>
                                    {isFeeBoosterActive ? '8%' : '20%'}
                                </span>
                            </div>
                            <button 
                                onClick={() => setIsFeeBoosterActive(!isFeeBoosterActive)}
                                className={`w-full py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all ${
                                    isFeeBoosterActive ? 'bg-emerald-600 text-white shadow-[0_0_20px_rgba(16,185,129,0.4)]' : 'bg-gray-800 text-emerald-500 border border-emerald-900/50 hover:bg-emerald-900/20'
                                }`}
                            >
                                {isFeeBoosterActive ? 'TAXA_REDUZIDA_ATIVA' : 'Queimar 100 NS para -12% Fee'}
                            </button>
                        </div>

                        <div className="bg-black/60 border border-white/5 p-6 rounded-[2rem] group cursor-pointer hover:border-cyan-500/30 transition-all">
                            <p className="text-gray-500 text-[10px] font-black uppercase mb-4 tracking-widest">Sintetizador de Ativos</p>
                            <div className="flex items-center gap-4 mb-6">
                                <div className="w-14 h-14 bg-cyan-950/30 rounded-2xl flex items-center justify-center text-cyan-400 border border-cyan-800">
                                    <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>
                                </div>
                                <div>
                                    <p className="text-white font-bold text-sm">Pronto para Sintetizar</p>
                                    <p className="text-[10px] text-gray-500 italic">5 aulas mineradas pendentes.</p>
                                </div>
                            </div>
                            <div className="w-full bg-gray-800 h-1.5 rounded-full overflow-hidden mb-2">
                                <div className="h-full bg-cyan-500 w-[100%] animate-pulse"></div>
                            </div>
                            <p className="text-[9px] text-cyan-500 font-black text-right uppercase tracking-widest">Gerar E-book Agora</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
