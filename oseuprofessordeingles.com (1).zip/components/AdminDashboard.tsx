
import React, { useState } from 'react';
import { Teacher } from '../types';
import { ExecutiveAdvisor } from './ExecutiveAdvisor';
import { ContentEngine } from './ContentEngine';
import { SystemConfiguration } from './SystemConfiguration';

type AdminTab = 'ECONOMY' | 'TEACHER_FACTORY' | 'SQUAD_COMANDER' | 'CONTENT_AUTO' | 'CORE_HEALTH';

export const AdminDashboard: React.FC<{ teachers: Teacher[] }> = ({ teachers }) => {
  const [activeTab, setActiveTab] = useState<AdminTab>('ECONOMY');
  
  // Regras do Comander
  const [squadRules, setSquadRules] = useState({
      minToActivate: 4,
      maxMembers: 6,
      leaderScholarshipEnabled: true,
      welcomeSessionRequired: true
  });

  return (
    <div className="min-h-screen pt-24 pb-20 font-sans bg-[#020202]">
      <div className="max-w-[1600px] mx-auto px-6">
        
        <div className="mb-12 flex justify-between items-end border-b border-gray-800 pb-8">
            <div>
                <h1 className="text-5xl font-black text-white font-orbitron tracking-tighter flex items-center gap-4">
                    MASTER_CONTROL
                    <span className="text-xs bg-emerald-500 text-black px-3 py-1 rounded font-mono font-bold animate-pulse">SYSTEM_ACTIVE</span>
                </h1>
                <p className="text-emerald-500 font-mono text-[10px] mt-2 uppercase tracking-[0.4em]">Soberania de Plataforma v4.2</p>
            </div>
            
            <div className="flex gap-2 bg-gray-900/80 p-1 rounded-2xl border border-white/5 shadow-2xl">
                {['ECONOMY', 'TEACHER_FACTORY', 'SQUAD_COMANDER', 'CONTENT_AUTO', 'CORE_HEALTH'].map(tab => (
                    <button 
                        key={tab}
                        onClick={() => setActiveTab(tab as AdminTab)}
                        className={`px-6 py-3 rounded-xl text-[10px] font-black tracking-widest uppercase transition-all ${
                            activeTab === tab ? 'bg-emerald-600 text-white shadow-[0_0_25px_rgba(16,185,129,0.3)]' : 'text-gray-500 hover:text-white'
                        }`}
                    >
                        {tab.replace('_', ' ')}
                    </button>
                ))}
            </div>
        </div>

        <div className="animate-fade-in">
            {activeTab === 'ECONOMY' && (
                <div className="space-y-8">
                    <div className="grid lg:grid-cols-4 gap-6">
                        <EconomicMetricCard label="Volume Total (GMV)" value="R$ 142.800" trend="+18%" color="emerald" />
                        <EconomicMetricCard label="Margem de Rede (Net)" value="R$ 28.560" trend="+5%" color="cyan" />
                        <EconomicMetricCard label="Ativos Digitais Criados" value="154" trend="+40%" color="purple" />
                        <EconomicMetricCard label="Squads Ativos" value="38" trend="+65%" color="yellow" />
                    </div>
                    <ExecutiveAdvisor />
                </div>
            )}

            {activeTab === 'SQUAD_COMANDER' && (
                <div className="grid lg:grid-cols-2 gap-8 animate-fade-in">
                    <div className="bg-gray-900 border border-gray-800 rounded-[3rem] p-10 shadow-2xl">
                        <h3 className="text-white font-orbitron font-bold text-xl mb-8 uppercase tracking-tight">Regras de Formação de Squad</h3>
                        <div className="space-y-10">
                            <AdminControlItem label="Mínimo de Mentes para Ativação" value={squadRules.minToActivate} sub="Ponto onde o Leader ganha bolsa" />
                            <AdminControlItem label="Capacidade Máxima Neural" value={squadRules.maxMembers} sub="Limite de alunos por turma" />
                            
                            <div className="pt-6 border-t border-white/5 space-y-6">
                                <div className="flex items-center justify-between">
                                    <div>
                                        <p className="text-white font-bold text-sm">Bolsa Integral para Líder</p>
                                        <p className="text-xs text-gray-500">Incentiva a criação de turmas</p>
                                    </div>
                                    <div className="w-12 h-6 bg-emerald-600 rounded-full flex items-center px-1 shadow-inner">
                                        <div className="w-4 h-4 bg-white rounded-full translate-x-6"></div>
                                    </div>
                                </div>
                                <div className="flex items-center justify-between">
                                    <div>
                                        <p className="text-white font-bold text-sm">Sessão de Acolhimento Obrigatória</p>
                                        <p className="text-xs text-gray-500">Validação humana pós-link</p>
                                    </div>
                                    <div className="w-12 h-6 bg-emerald-600 rounded-full flex items-center px-1 shadow-inner">
                                        <div className="w-4 h-4 bg-white rounded-full translate-x-6"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="bg-gray-900 border border-gray-800 rounded-[3rem] p-10 flex flex-col justify-center text-center opacity-50">
                        <div className="w-20 h-20 bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-6">
                             <svg className="w-10 h-10 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
                        </div>
                        <h4 className="text-white font-bold text-lg mb-2">Gráficos de Crescimento Squad</h4>
                        <p className="text-gray-500 text-sm">Módulo analítico em fase de sincronização neural.</p>
                    </div>
                </div>
            )}

            {activeTab === 'TEACHER_FACTORY' && (
                <div className="bg-gray-900/50 border border-gray-800 rounded-3xl overflow-hidden backdrop-blur-xl">
                    <table className="w-full text-left">
                        <thead className="bg-black/50 text-[10px] text-gray-500 uppercase tracking-widest border-b border-gray-800 font-black">
                            <tr>
                                <th className="p-6">Identidade Mentor</th>
                                <th className="p-6">Performance (HPC)</th>
                                <th className="p-6">Retenção de Capital</th>
                                <th className="p-6 text-right">Ações de Comando</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-800">
                            {teachers.map(t => (
                                <tr key={t.id} className="text-sm hover:bg-emerald-500/5 transition-colors">
                                    <td className="p-6 flex items-center gap-4">
                                        <img src={t.photoUrl} className="w-12 h-12 rounded-2xl object-cover border border-gray-700" alt={t.name} />
                                        <div>
                                            <span className="text-white font-bold block">{t.name}</span>
                                            <span className="text-[10px] text-gray-500 font-mono uppercase">{t.niche[0]}</span>
                                        </div>
                                    </td>
                                    <td className="p-6 font-mono text-emerald-400 font-bold">R$ {t.hourlyRate}/h</td>
                                    <td className="p-6">
                                        <div className="flex items-center gap-2">
                                            <div className="w-24 h-1.5 bg-gray-800 rounded-full overflow-hidden">
                                                <div className="h-full bg-emerald-500" style={{ width: '85%' }}></div>
                                            </div>
                                            <span className="text-xs font-bold text-white">85%</span>
                                        </div>
                                    </td>
                                    <td className="p-6 text-right">
                                        <button className="bg-gray-800 hover:bg-emerald-600 text-white px-4 py-2 rounded-lg text-[10px] font-black uppercase transition-all">Audit_Account</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}

            {activeTab === 'CONTENT_AUTO' && <ContentEngine />}
            {activeTab === 'CORE_HEALTH' && <SystemConfiguration />}
        </div>
      </div>
    </div>
  );
};

const AdminControlItem = ({ label, value, sub }: any) => (
    <div className="flex justify-between items-center bg-black/40 p-6 rounded-2xl border border-white/5 group hover:border-emerald-500/30 transition-all">
        <div>
            <p className="text-white font-bold text-sm mb-1">{label}</p>
            <p className="text-[10px] text-gray-600 uppercase font-bold tracking-tighter">{sub}</p>
        </div>
        <div className="flex items-center gap-4">
            <button className="w-8 h-8 rounded-lg bg-gray-800 flex items-center justify-center text-white hover:bg-red-900 transition-colors">-</button>
            <span className="text-2xl font-mono font-black text-emerald-400 w-8 text-center">{value}</span>
            <button className="w-8 h-8 rounded-lg bg-gray-800 flex items-center justify-center text-white hover:bg-emerald-600 transition-colors">+</button>
        </div>
    </div>
);

const EconomicMetricCard = ({ label, value, trend, color }: any) => (
    <div className="bg-gray-900 border border-gray-800 p-8 rounded-[2.5rem] relative overflow-hidden group">
        <div className={`absolute top-0 right-0 p-4 opacity-10 group-hover:scale-125 transition-transform text-${color}-500`}>
            <svg className="w-16 h-16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>
        </div>
        <p className="text-gray-500 text-[10px] uppercase font-black tracking-widest mb-2">{label}</p>
        <h3 className="text-4xl font-bold text-white font-mono">{value}</h3>
        <p className={`text-${color}-400 text-xs font-black mt-4 flex items-center gap-1`}>
            {trend} <span className="text-[10px] text-gray-600 uppercase tracking-tighter">vs last month</span>
        </p>
    </div>
);
