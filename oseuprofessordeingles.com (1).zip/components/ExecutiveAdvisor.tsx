
import React, { useState } from 'react';
import { generateExecutiveAnalysis } from '../services/geminiService';
import { dataService } from '../services/dataService';
import { INITIAL_PRICING_RULE, INITIAL_METRIC_WEIGHTS } from '../constants';

export const ExecutiveAdvisor: React.FC = () => {
    const [prompt, setPrompt] = useState('');
    const [analysis, setAnalysis] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [activeTab, setActiveTab] = useState<'ANALYSIS' | 'SIMULATOR' | 'GOVERNANCE'>('ANALYSIS');
    
    // States para o Simulador de Taxas
    const [simTakeRate, setSimTakeRate] = useState(INITIAL_PRICING_RULE.baseTakeRate);

    const handleAnalyze = async () => {
        if (!prompt.trim()) return;
        setIsLoading(true);
        setAnalysis(null);

        const secureSnapshot = await dataService.getSecureExecutiveSnapshot();
        const result = await generateExecutiveAnalysis(prompt, {
            ...secureSnapshot,
            active_rules: { ...INITIAL_PRICING_RULE, baseTakeRate: simTakeRate },
            weights: INITIAL_METRIC_WEIGHTS
        });
        
        setAnalysis(result);
        setIsLoading(false);
    };

    return (
        <div className="flex flex-col h-[calc(100vh-200px)] animate-fade-in font-sans">
            <div className="flex gap-1 mb-4 bg-gray-900/50 p-1 rounded-xl border border-gray-800 self-start">
                {['ANALYSIS', 'SIMULATOR', 'GOVERNANCE'].map(t => (
                    <button 
                        key={t}
                        onClick={() => setActiveTab(t as any)}
                        className={`px-4 py-1.5 rounded-lg text-[10px] font-black tracking-widest uppercase transition-all ${
                            activeTab === t ? 'bg-red-600 text-white shadow-lg' : 'text-gray-500 hover:text-white'
                        }`}
                    >
                        {t}
                    </button>
                ))}
            </div>

            <div className="grid lg:grid-cols-3 gap-6 flex-1 overflow-hidden">
                <div className="lg:col-span-2 flex flex-col bg-[#050505] border border-red-900/30 rounded-3xl overflow-hidden shadow-2xl relative">
                    <div className="bg-red-950/20 px-6 py-3 border-b border-red-900/30 flex justify-between items-center">
                        <div className="flex items-center gap-3">
                            <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></div>
                            <span className="text-[10px] font-mono text-red-500 tracking-widest uppercase">Master_Strategy_Kernel_v3.2</span>
                        </div>
                        <span className="text-[10px] font-mono text-gray-600 uppercase">Encrypted Session: AES-256</span>
                    </div>

                    <div className="flex-1 overflow-y-auto p-8 custom-scrollbar bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]">
                        {activeTab === 'SIMULATOR' ? (
                            <div className="space-y-10 animate-fade-in">
                                <div>
                                    <h3 className="text-white font-bold text-xl mb-2">Simulador de Yield vs Retenção</h3>
                                    <p className="text-gray-500 text-sm">Ajuste o Take Rate base para ver como o cérebro neural projeta a saúde da rede.</p>
                                </div>
                                <div className="bg-black/60 p-8 rounded-3xl border border-gray-800">
                                    <div className="flex justify-between items-end mb-6">
                                        <span className="text-xs text-gray-500 font-black uppercase">Take Rate Base (%)</span>
                                        <span className="text-4xl font-mono font-black text-cyan-400">{simTakeRate}%</span>
                                    </div>
                                    <input 
                                        type="range" min="5" max="40" step="1" 
                                        value={simTakeRate} 
                                        onChange={(e) => setSimTakeRate(Number(e.target.value))}
                                        className="w-full accent-cyan-500 h-2 bg-gray-800 rounded-full appearance-none cursor-pointer mb-8"
                                    />
                                    <div className="grid grid-cols-2 gap-4">
                                        <div className="bg-gray-900 p-4 rounded-xl border border-gray-800">
                                            <p className="text-[10px] text-gray-500 uppercase font-bold mb-1">Impacto Professores</p>
                                            <p className={`text-lg font-bold ${simTakeRate > 25 ? 'text-red-500' : 'text-green-500'}`}>
                                                {simTakeRate > 25 ? 'ALTO RISCO_CHURN' : 'ESTÁVEL_ATRATIVO'}
                                            </p>
                                        </div>
                                        <div className="bg-gray-900 p-4 rounded-xl border border-gray-800">
                                            <p className="text-[10px] text-gray-500 uppercase font-bold mb-1">Yield Projetado</p>
                                            <p className="text-lg font-bold text-white">R$ {(45230 * (simTakeRate/100)).toFixed(0)}</p>
                                        </div>
                                    </div>
                                    <button 
                                        onClick={() => { setPrompt(`Simule o impacto de um Take Rate de ${simTakeRate}% na base de professores ELITE nos próximos 90 dias.`); handleAnalyze(); setActiveTab('ANALYSIS'); }}
                                        className="w-full mt-8 bg-red-600 hover:bg-red-500 text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest transition-all"
                                    >
                                        Solicitar Relatório IA de Impacto
                                    </button>
                                </div>
                            </div>
                        ) : (
                            <>
                                {analysis ? (
                                    <div className="animate-slide-up prose prose-invert max-w-none prose-sm leading-relaxed">
                                        {analysis.split('\n').map((line, i) => {
                                            if (line.match(/^\*\*.*\*\*$/)) return <h4 key={i} className="text-red-500 uppercase tracking-widest mt-8 first:mt-0 border-b border-red-900/20 pb-2">{line.replace(/\*\*/g, '')}</h4>;
                                            return <p key={i} className="text-gray-400 mb-3">{line}</p>;
                                        })}
                                    </div>
                                ) : (
                                    <div className="h-full flex flex-col items-center justify-center text-center opacity-30 grayscale">
                                        <div className="w-24 h-24 border-2 border-dashed border-red-900/50 rounded-full flex items-center justify-center mb-6">
                                            <svg className="w-12 h-12 text-red-900" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                                        </div>
                                        <p className="font-mono text-xs uppercase tracking-[0.3em] text-red-900">Aguardando Input Estratégico</p>
                                    </div>
                                )}
                            </>
                        )}
                        {isLoading && (
                            <div className="flex flex-col items-center justify-center h-full space-y-4">
                                <div className="w-10 h-10 border-2 border-red-600 border-t-transparent rounded-full animate-spin"></div>
                                <p className="text-red-500 font-mono text-[10px] uppercase tracking-widest animate-pulse">Consulting Neural Core...</p>
                            </div>
                        )}
                    </div>

                    <div className="p-6 bg-black border-t border-red-900/20">
                        <div className="relative">
                            <textarea 
                                value={prompt}
                                onChange={(e) => setPrompt(e.target.value)}
                                onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), handleAnalyze())}
                                placeholder="Descreva o dilema, mudança de preço ou política..."
                                className="w-full bg-red-950/5 border border-red-900/30 rounded-2xl px-6 py-5 text-white focus:border-red-600 outline-none transition-all resize-none h-28 font-sans text-sm shadow-inner"
                                disabled={isLoading}
                            />
                            <button 
                                onClick={handleAnalyze}
                                disabled={isLoading || !prompt.trim()}
                                className="absolute right-4 bottom-4 bg-red-600 hover:bg-red-500 disabled:opacity-20 text-black p-3 rounded-xl shadow-lg transition-all group"
                            >
                                <svg className="w-5 h-5 group-hover:scale-110" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                            </button>
                        </div>
                    </div>
                </div>

                <div className="space-y-6">
                    <div className="bg-gray-900 border border-gray-800 rounded-3xl p-6 shadow-xl">
                        <h3 className="text-white font-black text-[10px] uppercase tracking-widest mb-6 flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-cyan-500"></span>
                            Status Global Atual
                        </h3>
                        <div className="space-y-4">
                            <div className="flex justify-between items-center border-b border-gray-800 pb-3">
                                <span className="text-gray-500 text-[10px] uppercase font-bold">Take Rate Atual</span>
                                <span className="text-xl font-mono font-bold text-white">{INITIAL_PRICING_RULE.baseTakeRate}%</span>
                            </div>
                            <div className="flex justify-between items-center">
                                <span className="text-gray-500 text-[10px] uppercase font-bold">Churn Professores</span>
                                <span className="text-lg font-mono font-bold text-green-500">1.2%</span>
                            </div>
                            <div className="mt-6 p-4 bg-cyan-950/20 border border-cyan-900/50 rounded-xl">
                                <p className="text-[10px] text-cyan-400 font-bold uppercase mb-1">Recomendação Macley</p>
                                <p className="text-[10px] text-gray-400 leading-relaxed italic">"Baseado no snapshot atual, reduzir o Take Rate para Professores ELITE para 15% aumentaria a retenção de alunos em 8%."</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
