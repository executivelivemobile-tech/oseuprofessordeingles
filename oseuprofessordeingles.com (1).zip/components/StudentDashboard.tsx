
import React, { useState } from 'react';
import { User, Booking, Squad } from '../types';
import { NeuralQuotaHUD } from './NeuralQuotaHUD';
import { SquadFormation } from './SquadFormation';

export const StudentDashboard: React.FC<{ currentUser: User; bookings: Booking[]; activeSquads: Squad[] }> = ({ currentUser, bookings, activeSquads }) => {
  const [tab, setTab] = useState<'MISSIONS' | 'SQUADS' | 'VALUATION'>('MISSIONS');

  return (
    <div className="min-h-screen pt-24 px-6 max-w-[1600px] mx-auto pb-20 font-sans">
      {/* Perfil HUD */}
      <div className="flex flex-col md:flex-row justify-between items-end mb-12 border-b border-gray-800 pb-8 gap-8">
          <div className="flex items-center gap-8">
              <div className="relative">
                  <img src={currentUser.avatarUrl} className="w-24 h-24 rounded-[2rem] border-4 border-cyan-500 shadow-2xl object-cover" />
                  <div className="absolute -bottom-2 -right-2 bg-black border border-cyan-500 text-cyan-400 px-3 py-1 rounded-xl font-black text-[10px] shadow-lg uppercase tracking-widest">
                      Rank: {currentUser.rank}
                  </div>
              </div>
              <div>
                  <h1 className="text-5xl font-black text-white font-orbitron tracking-tighter">{currentUser.name}</h1>
                  <div className="flex items-center gap-4 mt-3">
                      <div className="w-64 h-1.5 bg-gray-900 rounded-full border border-white/5 overflow-hidden">
                          <div className="h-full bg-gradient-to-r from-cyan-600 to-blue-500" style={{ width: '65%' }}></div>
                      </div>
                      <span className="text-[10px] text-gray-500 font-mono uppercase font-bold tracking-widest">XP: {currentUser.xp}/2500</span>
                  </div>
              </div>
          </div>

          <div className="flex gap-4">
              <div className="bg-gray-900 border border-gray-800 p-6 rounded-[2rem] text-center min-w-[140px]">
                  <p className="text-gray-500 text-[10px] font-black uppercase tracking-widest mb-1">Fluência</p>
                  <p className="text-4xl font-bold text-white font-mono">C1</p>
              </div>
              <div className="bg-gradient-to-br from-purple-900/40 to-black border border-purple-500/30 p-6 rounded-[2rem] text-center min-w-[140px]">
                  <p className="text-purple-400 text-[10px] font-black uppercase tracking-widest mb-1">Squad ROI</p>
                  <p className="text-4xl font-bold text-white font-mono">-40%</p>
              </div>
          </div>
      </div>

      <div className="grid lg:grid-cols-12 gap-8">
          {/* Main Console */}
          <div className="lg:col-span-8 space-y-10">
              <div className="flex gap-2 bg-gray-900/50 p-1.5 rounded-2xl border border-white/5 self-start inline-flex">
                  {(['MISSIONS', 'SQUADS', 'VALUATION'] as const).map(t => (
                      <button 
                        key={t} onClick={() => setTab(t)}
                        className={`px-8 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                            tab === t ? 'bg-cyan-600 text-white shadow-lg' : 'text-gray-500 hover:text-white'
                        }`}
                      >
                          {t}
                      </button>
                  ))}
              </div>

              <div className="animate-fade-in">
                  {tab === 'MISSIONS' && (
                      <div className="space-y-6">
                          <h3 className="text-white font-bold text-xl mb-4">Próximas Sincronias</h3>
                          {bookings.length > 0 ? (
                              bookings.map(b => (
                                  <div key={b.id} className="bg-gray-900 border border-gray-800 p-8 rounded-[2.5rem] flex justify-between items-center group hover:border-cyan-500/30 transition-all">
                                      <div className="flex items-center gap-6">
                                          <div className="w-16 h-16 rounded-2xl bg-gray-800 flex items-center justify-center text-3xl">👨‍🏫</div>
                                          <div>
                                              <p className="text-white font-bold text-xl">{b.teacherName}</p>
                                              <p className="text-cyan-500 text-sm font-mono">{b.date} • {b.timeSlot}</p>
                                          </div>
                                      </div>
                                      <button className="bg-white text-black px-10 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-cyan-400 transition-all">Iniciar_Sala</button>
                                  </div>
                              ))
                          ) : (
                              <div className="py-20 text-center bg-black border border-dashed border-gray-800 rounded-[2.5rem] text-gray-500 uppercase text-xs tracking-widest font-black">
                                  Nenhuma missão ativa. <br/> <span className="text-cyan-500 mt-2 block">Acesse o Mercado para Recrutar um Mentor.</span>
                              </div>
                          )}
                      </div>
                  )}

                  {tab === 'SQUADS' && (
                      <SquadFormation user={currentUser} activeSquads={activeSquads} onCreateSquad={() => {}} onShareSquad={() => {}} />
                  )}
              </div>
          </div>

          {/* Sidebar Metrics */}
          <div className="lg:col-span-4 space-y-8">
              <NeuralQuotaHUD user={currentUser} />
              
              <div className="bg-gray-900 border border-gray-800 rounded-[2.5rem] p-8 shadow-xl">
                  <h4 className="text-gray-500 font-black text-[10px] uppercase tracking-widest mb-8">Comando de Utilidade IA</h4>
                  <div className="space-y-4">
                      <UtilityButton icon="🎯" label="Simulador de Roleplay" cost="15 NS" color="purple" />
                      <UtilityButton icon="✍️" label="Corretor de Redação" cost="8 NS" color="cyan" />
                      <UtilityButton icon="👑" label="Legend Mode (Slangs)" cost="10 NS" color="pink" />
                  </div>
              </div>
          </div>
      </div>
    </div>
  );
};

const UtilityButton = ({ icon, label, cost, color }: any) => (
    <button className="w-full flex items-center justify-between p-5 bg-black/40 border border-gray-800 rounded-3xl hover:border-white/20 transition-all group">
        <div className="flex items-center gap-4">
            <span className="text-2xl">{icon}</span>
            <span className="text-white font-bold text-sm group-hover:text-cyan-400 transition-colors">{label}</span>
        </div>
        <span className={`text-[10px] font-mono font-black uppercase text-${color}-500`}>{cost}</span>
    </button>
);
