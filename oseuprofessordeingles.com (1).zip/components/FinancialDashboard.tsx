
import React, { useState, useEffect } from 'react';
import { TeacherWallet, LedgerEntry } from '../types';
import { financialEngine } from '../services/financialEngine';

export const FinancialDashboard: React.FC<{ teacherId: string; language: 'EN' | 'PT' }> = ({ teacherId, language }) => {
    const [wallet, setWallet] = useState<TeacherWallet | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [isProcessing, setIsProcessing] = useState(false);
    const isPT = language === 'PT';

    useEffect(() => {
        refreshWallet();
    }, [teacherId]);

    const refreshWallet = async () => {
        setIsLoading(true);
        const data = await financialEngine.getTeacherWallet(teacherId);
        setWallet(data);
        setIsLoading(false);
    };

    const handleWithdrawal = async () => {
        if (!wallet) return;
        
        const confirm = window.confirm(
            isPT 
            ? `Confirmar o saque TOTAL de R$ ${wallet.currentBalance.toFixed(2)}? Seu saldo retornará a zero e você não poderá sacar novamente hoje.`
            : `Confirm TOTAL withdrawal of R$ ${wallet.currentBalance.toFixed(2)}? Your balance will return to zero and you cannot withdraw again today.`
        );

        if (!confirm) return;

        setIsProcessing(true);
        const result = await financialEngine.requestTotalWithdrawal(teacherId);
        alert(result.message);
        await refreshWallet();
        setIsProcessing(false);
    };

    if (isLoading || !wallet) {
        return (
            <div className="flex flex-col items-center justify-center h-64 animate-pulse">
                <div className="w-12 h-12 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin mb-4"></div>
                <p className="text-emerald-500 font-mono text-[10px] uppercase tracking-widest">Sincronizando Ledger...</p>
            </div>
        );
    }

    const canWithdraw = wallet.currentBalance > 0 && wallet.lastWithdrawalDate !== new Date().toISOString().split('T')[0];

    return (
        <div className="animate-fade-in space-y-8 font-sans">
            {/* HUD de Saldo */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="md:col-span-2 bg-gradient-to-br from-[#0a0a0a] to-[#020202] border border-emerald-500/20 rounded-[2.5rem] p-10 relative overflow-hidden shadow-2xl">
                    <div className="absolute top-0 right-0 p-10 opacity-5">
                        <svg className="w-40 h-40" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>
                    </div>
                    
                    <div className="relative z-10">
                        <p className="text-gray-500 text-[10px] font-black uppercase tracking-[0.4em] mb-4">Saldo Disponível (Real-Time)</p>
                        <h2 className="text-6xl font-bold text-white font-orbitron mb-10 tracking-tighter">
                            R$ {wallet.currentBalance.toFixed(2)}
                        </h2>
                        
                        <div className="flex flex-col sm:flex-row gap-4">
                            <button 
                                onClick={handleWithdrawal}
                                disabled={!canWithdraw || isProcessing}
                                className={`px-10 py-5 rounded-2xl font-black text-xs uppercase tracking-widest transition-all shadow-xl flex items-center justify-center gap-3 ${
                                    canWithdraw 
                                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-900/40' 
                                    : 'bg-gray-800 text-gray-500 cursor-not-allowed border border-white/5'
                                }`}
                            >
                                {isProcessing ? 'PROCESSANDO...' : (isPT ? 'RESGATAR VALOR TOTAL' : 'WITHDRAW TOTAL BALANCE')}
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
                            </button>
                            {!canWithdraw && wallet.currentBalance > 0 && (
                                <p className="text-[9px] text-red-500 uppercase font-black self-center max-w-[150px] leading-tight animate-pulse">
                                    Limite de 1 saque diário atingido. Próximo saque disponível amanhã.
                                </p>
                            )}
                        </div>
                    </div>
                </div>

                <div className="bg-[#0a0a0a] border border-white/5 rounded-[2.5rem] p-8 flex flex-col justify-center">
                    <p className="text-gray-500 text-[10px] font-black uppercase tracking-widest mb-2">Acumulado Histórico</p>
                    <p className="text-3xl font-bold text-white font-mono mb-6">R$ {wallet.totalEarnedLifetime.toFixed(2)}</p>
                    <div className="h-px bg-white/5 w-full mb-6"></div>
                    <p className="text-gray-500 text-[10px] font-black uppercase tracking-widest mb-2">Status da Conta</p>
                    <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.5)]"></div>
                        <span className="text-xs font-bold text-emerald-500 uppercase tracking-widest">Ativa & Compliance</span>
                    </div>
                </div>
            </div>

            {/* Trilha de Auditoria (Ledger) */}
            <div className="bg-[#0a0a0a] border border-white/5 rounded-[2.5rem] overflow-hidden shadow-2xl">
                <div className="p-8 border-b border-white/5 flex justify-between items-center bg-black/40">
                    <h3 className="text-white font-bold text-lg font-orbitron tracking-tight">OSPI_LEDGER_AUDIT</h3>
                    <span className="text-[9px] text-gray-600 font-mono uppercase">V4.1 Protocol Immutable Logs</span>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead>
                            <tr className="text-[10px] text-gray-500 uppercase font-black tracking-widest bg-black/20">
                                <th className="p-6">Timestamp</th>
                                <th className="p-6">Evento_Financeiro</th>
                                <th className="p-6">Ref_ID</th>
                                <th className="p-6 text-right">Crédito/Débito</th>
                                <th className="p-6 text-right">Saldo_Residual</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-white/5">
                            {wallet.entries.map((entry) => (
                                <tr key={entry.id} className="text-sm hover:bg-white/[0.02] transition-colors font-mono">
                                    <td className="p-6 text-gray-500 text-xs">{new Date(entry.timestamp).toLocaleString()}</td>
                                    <td className="p-6">
                                        <div className="flex items-center gap-3">
                                            <span className={`w-1.5 h-1.5 rounded-full ${entry.type === 'WITHDRAWAL_TOTAL' ? 'bg-red-500' : 'bg-cyan-500'}`}></span>
                                            <div>
                                                <p className="text-white font-bold text-xs uppercase">{entry.type}</p>
                                                <p className="text-[10px] text-gray-600">{entry.description}</p>
                                            </div>
                                        </div>
                                    </td>
                                    <td className="p-6 text-gray-600 text-xs uppercase">{entry.referenceId.substr(0, 12)}...</td>
                                    <td className={`p-6 text-right font-bold ${entry.netAmount < 0 ? 'text-red-500' : 'text-emerald-400'}`}>
                                        {entry.netAmount > 0 ? '+' : ''} R$ {entry.netAmount.toFixed(2)}
                                    </td>
                                    <td className="p-6 text-right text-gray-400 font-bold">R$ {entry.balanceAfter.toFixed(2)}</td>
                                </tr>
                            ))}
                            {wallet.entries.length === 0 && (
                                <tr>
                                    <td colSpan={5} className="p-20 text-center text-gray-700 uppercase text-xs font-black tracking-widest italic">
                                        Nenhuma atividade financeira registrada no ledger.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* Aviso Legal de Anti-Banco */}
            <div className="p-8 bg-emerald-950/10 border border-emerald-900/30 rounded-3xl">
                <div className="flex gap-4 items-start">
                    <svg className="w-6 h-6 text-emerald-500 shrink-0 mt-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                    <div>
                        <h4 className="text-emerald-500 font-bold text-sm uppercase mb-1">Aviso de Governança Financeira</h4>
                        <p className="text-gray-500 text-xs leading-relaxed">
                            Esta conta interna serve exclusivamente para trânsito operacional. Não é permitida a retenção prolongada de valores. Saques devem ser realizados assim que o saldo estiver disponível. A plataforma não é uma instituição financeira e não oferece custódia de investimentos.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    );
};
