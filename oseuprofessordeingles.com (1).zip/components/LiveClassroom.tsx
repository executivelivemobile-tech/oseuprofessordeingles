
import React, { useState, useEffect } from 'react';
import { Booking, Teacher } from '../types';
import { TechCheck } from './TechCheck';
import { Whiteboard } from './Whiteboard';
import { financialEngine } from '../services/financialEngine';

interface LiveClassroomProps {
  booking: Booking;
  teacher?: Teacher;
  onEndCall: () => void;
}

export const LiveClassroom: React.FC<LiveClassroomProps> = ({ booking, teacher, onEndCall }) => {
  const [sessionState, setSessionState] = useState<'CHECK' | 'LIVE' | 'RESTRICTED'>('CHECK');
  const [micOn, setMicOn] = useState(true);
  const [camOn, setCamOn] = useState(true);
  const [timer, setTimer] = useState(3000); // 50 mins
  const [isFinishing, setIsFinishing] = useState(false);

  // REGRA DE OURO: Bloqueio imediato se não estiver pago
  useEffect(() => {
      if (booking.paymentStatus !== 'PAID') {
          setSessionState('RESTRICTED');
      }
  }, [booking]);

  useEffect(() => {
    let interval: any;
    if (sessionState === 'LIVE') {
        interval = setInterval(() => {
            setTimer((prev) => (prev > 0 ? prev - 1 : 0));
        }, 1000);
    }
    return () => clearInterval(interval);
  }, [sessionState]);

  const handleEndLesson = async () => {
      if (!teacher) return;
      
      setIsFinishing(true);
      
      // GATILHO DE CRÉDITO: Só ocorre no encerramento real e validado
      console.log(`[LEDGER] Finalizando aula ${booking.id}. Gerando crédito para ${teacher.id}`);
      await financialEngine.creditLessonCompletion(teacher.id, booking.id, teacher.hourlyRate);
      
      onEndCall();
  };

  if (sessionState === 'RESTRICTED') {
      return (
          <div className="fixed inset-0 z-[100] bg-black flex flex-col items-center justify-center p-8 text-center animate-fade-in">
              <div className="w-24 h-24 bg-red-950/30 border border-red-500 rounded-full flex items-center justify-center mb-8 shadow-[0_0_40px_rgba(239,68,68,0.3)]">
                  <svg className="w-12 h-12 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
              </div>
              <h2 className="text-3xl font-black text-white mb-4 font-orbitron uppercase tracking-tighter">Sincronia_Bloqueada</h2>
              <p className="text-gray-500 max-w-sm mb-8 leading-relaxed">
                  O token de pagamento para esta sessão não foi validado. A aula não pode ser iniciada até que o sistema detecte o aporte no Escrow.
              </p>
              <button onClick={onEndCall} className="bg-white text-black px-10 py-4 rounded-2xl font-black text-xs uppercase tracking-widest">Retornar ao Dashboard</button>
          </div>
      );
  }

  if (sessionState === 'CHECK') {
      return <TechCheck onJoin={() => setSessionState('LIVE')} onCancel={onEndCall} />;
  }

  return (
    <div className="fixed inset-0 bg-black z-50 flex flex-col font-sans">
      {/* HUD Header */}
      <div className="absolute top-0 left-0 right-0 p-4 z-30 flex justify-between items-start">
        <div className="bg-black/80 backdrop-blur-md border border-cyan-500/30 px-6 py-3 rounded-2xl flex items-center gap-3">
           <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></div>
           <span className="text-white text-xs font-black tracking-widest uppercase">MISSION_ACTIVE</span>
           <div className="h-4 w-px bg-gray-800 mx-2"></div>
           <span className="text-cyan-400 font-mono text-sm font-bold tracking-tighter">PAID_SESSIONS: 1/1</span>
        </div>
        
        <div className="bg-black/80 backdrop-blur-md border border-emerald-500/30 px-6 py-3 rounded-2xl flex items-center gap-3">
            <svg className="w-4 h-4 text-emerald-500" fill="currentColor" viewBox="0 0 20 20"><path d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"/></svg>
            <span className="text-emerald-500 text-[10px] font-black uppercase tracking-widest">Transação_Segura_Ativa</span>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
          <div className="flex-1 relative bg-[#020202] flex items-center justify-center overflow-hidden">
              <div className="absolute inset-0 flex flex-col items-center justify-center z-10">
                  <div className="p-12 text-center max-w-md">
                      <div className="w-24 h-24 bg-gray-900/50 rounded-full flex items-center justify-center mx-auto mb-8 border border-white/5 shadow-2xl">
                          <svg className="w-12 h-12 text-cyan-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 0-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
                      </div>
                      <h3 className="text-2xl font-bold text-white mb-2 font-orbitron tracking-tight">SINC_NEURAL_ESTRATÉGICA</h3>
                      <p className="text-gray-500 mb-8 text-sm uppercase tracking-widest font-bold">Inicie o link de vídeo seguro externo para alta fidelidade.</p>
                      <button onClick={() => window.open('https://meet.google.com/new', '_blank')} className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-black py-5 rounded-3xl shadow-2xl transition-all uppercase text-xs tracking-[0.2em]">
                          Lançar Terminal de Vídeo
                      </button>
                  </div>
              </div>
          </div>

          <div className="w-96 bg-[#080808] border-l border-white/5 flex flex-col">
              <div className="p-8 flex-1">
                  <h4 className="text-gray-500 text-[10px] font-black uppercase tracking-[0.3em] mb-8">Informações_da_Aula</h4>
                  <div className="bg-black/60 p-6 rounded-3xl border border-white/5 space-y-6">
                      <div>
                          <p className="text-gray-600 text-[9px] uppercase font-bold mb-1">Mestre_Mentor</p>
                          <p className="text-white font-bold text-lg">{teacher?.name || booking.teacherName}</p>
                      </div>
                      <div>
                          <p className="text-gray-600 text-[9px] uppercase font-bold mb-1">Sessão_ID</p>
                          <p className="text-cyan-500 font-mono text-xs">{booking.id}</p>
                      </div>
                      <div className="pt-6 border-t border-white/5">
                           <p className="text-emerald-500 text-[10px] font-black uppercase tracking-widest mb-2">Escrow_Status</p>
                           <div className="flex items-center justify-between">
                               <span className="text-white font-bold text-sm">R$ {teacher?.hourlyRate.toFixed(2)}</span>
                               <span className="text-[9px] bg-emerald-950 text-emerald-400 px-2 py-0.5 rounded uppercase font-black tracking-widest border border-emerald-800">Liberável_em_T-0</span>
                           </div>
                      </div>
                  </div>
              </div>

              <div className="p-8 border-t border-white/5 bg-black/40">
                  <button 
                    onClick={handleEndLesson}
                    disabled={isFinishing}
                    className="w-full bg-red-600 hover:bg-red-500 text-white py-5 rounded-3xl font-black text-xs uppercase tracking-widest shadow-2xl shadow-red-900/40 transition-all disabled:opacity-30"
                  >
                      {isFinishing ? 'Sincronizando Ledger...' : 'Encerrar Missão e Creditar'}
                  </button>
                  <p className="text-center text-[9px] text-gray-700 mt-4 uppercase font-bold tracking-tighter">Ao encerrar, o valor líquido será creditado instantaneamente ao mestre.</p>
              </div>
          </div>
      </div>
    </div>
  );
};
