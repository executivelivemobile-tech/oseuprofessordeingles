
import React, { useState, useEffect } from 'react';
import { User, UserRole, ViewState } from '../types';

interface NavbarProps {
    currentUser: User | null;
    currentView: ViewState;
    onNavigate: (view: ViewState) => void;
    onOpenAuth: (mode: 'LOGIN' | 'REGISTER') => void;
    onLogout: () => void;
    hasUnread?: boolean;
    language: 'EN' | 'PT';
    onToggleLanguage: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ 
    currentUser, 
    currentView, 
    onNavigate, 
    onOpenAuth, 
    onLogout, 
    hasUnread,
    language,
    onToggleLanguage
}) => {
    const [systemTime, setSystemTime] = useState('');
    const isAdmin = currentUser?.role === UserRole.SUPERADMIN || currentUser?.role === UserRole.ADMIN;

    useEffect(() => {
        const timer = setInterval(() => {
            const now = new Date();
            setSystemTime(now.toLocaleTimeString('pt-BR', { hour12: false }));
        }, 1000);
        return () => clearInterval(timer);
    }, []);

    return (
        <nav className="fixed top-0 w-full z-[100] px-6 py-5 pointer-events-none">
            {/* HUD Central Container */}
            <div className={`max-w-7xl mx-auto h-20 pointer-events-auto relative rounded-2xl border transition-all duration-700 overflow-hidden ${
                isAdmin ? 'border-red-500/30' : 'border-white/10'
            }`}>
                
                {/* Glassmorphism Background */}
                <div className="absolute inset-0 bg-black/60 backdrop-blur-2xl"></div>
                
                {/* Neural Scanline Effect */}
                <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-cyan-500/40 to-transparent opacity-50 animate-scan pointer-events-none"></div>

                <div className="relative h-full flex items-center justify-between px-8">
                    
                    {/* BRANDING: O SEU PROFESSOR */}
                    <div className="flex items-center cursor-pointer group" onClick={() => onNavigate('HOME')}>
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-white font-black font-orbitron transition-transform duration-500 group-hover:rotate-[360deg] ${
                            isAdmin ? 'bg-red-600 shadow-[0_0_20px_rgba(220,38,38,0.5)]' : 'bg-cyan-600 shadow-[0_0_20px_rgba(6,182,212,0.5)]'
                        }`}>
                            {isAdmin ? 'A' : 'O'}
                        </div>
                        <div className="ml-4 flex flex-col">
                            <span className="text-xl font-orbitron font-black tracking-tighter leading-none text-white">
                                O SEU PROFESSOR
                            </span>
                            <span className="text-[8px] font-mono text-cyan-500 uppercase tracking-[0.4em] mt-1 font-black">
                                {isAdmin ? 'ADMIN_PROTOCOL_ACTIVE' : 'LEARNING_ECOSYSTEM_V4'}
                            </span>
                        </div>
                    </div>

                    {/* TERMINAL LINKS */}
                    <div className="hidden lg:flex items-center gap-2">
                        {!isAdmin ? (
                            <>
                                <NavLink active={currentView === 'FIND_TEACHER'} onClick={() => onNavigate('FIND_TEACHER')}>
                                    <span className="opacity-30 mr-2">01</span> MENTORES
                                </NavLink>
                                <NavLink active={currentView === 'COURSES'} onClick={() => onNavigate('COURSES')}>
                                    <span className="opacity-30 mr-2">02</span> CURSOS
                                </NavLink>
                                {currentUser && (
                                    <NavLink active={currentView === 'SQUAD_HUB'} onClick={() => onNavigate('SQUAD_HUB')} highlight="cyan">
                                        <span className="animate-pulse mr-2 text-cyan-400">●</span> SQUAD_SYNC
                                    </NavLink>
                                )}
                            </>
                        ) : (
                            <NavLink active={currentView === 'ADMIN_DASHBOARD'} onClick={() => onNavigate('ADMIN_DASHBOARD')} highlight="red">
                                <span className="animate-pulse mr-2 text-red-500">●</span> MASTER_CONTROL
                            </NavLink>
                        )}
                    </div>

                    {/* SYSTEM INFO & AUTH */}
                    <div className="flex items-center gap-6">
                        {/* System Status Display */}
                        <div className="hidden xl:flex flex-col items-end border-r border-white/10 pr-6">
                            <div className="flex items-center gap-2">
                                <span className="text-[9px] font-black text-gray-500 uppercase tracking-widest">Neural_Link: Stable</span>
                                <div className="w-1.5 h-1.5 rounded-full bg-green-500"></div>
                            </div>
                            <span className="text-xs font-mono text-cyan-500/80 font-bold">{systemTime}</span>
                        </div>

                        {currentUser ? (
                            <div className="flex items-center gap-4 group/user relative cursor-pointer">
                                <div className="text-right hidden sm:block">
                                    <div className="text-[10px] font-black text-white uppercase tracking-tighter leading-none">{currentUser.name}</div>
                                    <div className="text-[8px] uppercase font-bold mt-1 text-cyan-500">Rank: {currentUser.rank}</div>
                                </div>
                                <img src={currentUser.avatarUrl} className="w-10 h-10 rounded-xl border-2 border-white/10 group-hover/user:border-cyan-500 transition-colors object-cover" />
                                
                                {/* Dropdown HUD */}
                                <div className="absolute top-full right-0 mt-4 w-56 bg-black/90 backdrop-blur-3xl border border-white/10 rounded-2xl p-2 opacity-0 invisible group-hover/user:opacity-100 group-hover/user:visible transition-all transform origin-top-right scale-95 group-hover/user:scale-100 shadow-[0_20px_50px_rgba(0,0,0,0.8)]">
                                    <button onClick={() => onNavigate('STUDENT_DASHBOARD')} className="w-full text-left px-4 py-3 text-[10px] font-black text-gray-400 hover:text-white hover:bg-white/5 rounded-xl transition-all uppercase tracking-widest">Dashboard</button>
                                    <button onClick={() => onNavigate('SETTINGS')} className="w-full text-left px-4 py-3 text-[10px] font-black text-gray-400 hover:text-white hover:bg-white/5 rounded-xl transition-all uppercase tracking-widest">Configurações</button>
                                    <div className="h-px bg-white/5 my-1"></div>
                                    <button onClick={onLogout} className="w-full text-left px-4 py-3 text-[10px] font-black text-red-500 hover:bg-red-500/10 rounded-xl transition-all uppercase tracking-widest">Encerrar Sessão</button>
                                </div>
                            </div>
                        ) : (
                            <div className="flex items-center gap-2">
                                <button onClick={() => onOpenAuth('LOGIN')} className="px-5 py-2 text-[10px] font-black text-gray-400 hover:text-white uppercase tracking-widest">Entrar</button>
                                <button onClick={() => onOpenAuth('REGISTER')} className="bg-white text-black px-6 py-2.5 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-cyan-500 hover:text-white transition-all transform active:scale-95 shadow-xl">Cadastrar</button>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </nav>
    );
};

const NavLink: React.FC<{ children: React.ReactNode; active: boolean; onClick: () => void; highlight?: 'cyan' | 'red' }> = ({ children, active, onClick, highlight }) => (
    <button 
        onClick={onClick}
        className={`px-5 py-2 rounded-xl text-[11px] font-black uppercase tracking-[0.2em] transition-all relative overflow-hidden group ${
            active 
            ? (highlight === 'red' ? 'text-red-500' : 'text-cyan-400') 
            : 'text-gray-500 hover:text-white'
        }`}
    >
        <span className="relative z-10 flex items-center">{children}</span>
        {active && (
            <div className={`absolute bottom-0 left-5 right-5 h-0.5 rounded-full ${highlight === 'red' ? 'bg-red-500 shadow-[0_0_10px_rgba(239,68,68,0.8)]' : 'bg-cyan-500 shadow-[0_0_10px_rgba(6,182,212,0.8)]'}`}></div>
        )}
        <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
    </button>
);
